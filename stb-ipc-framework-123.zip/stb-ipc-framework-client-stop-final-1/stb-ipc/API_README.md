# STB IPC Framework — API Reference

This document describes the public C++ APIs and the C ABI wrapper in `include/stbipc/`. The framework is a Linux prototype for communication between a WebKitWPE WebProcess plugin and a separate native Middleware process. The core is C++17; `stbipc/c_api.h` allows C modules to use the client without including C++ headers.

## 1. Build and run

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j4
ctest --test-dir build --output-on-failure
```

Demo:

```bash
# Terminal 1: Middleware-side server
./build/stb_ipc_server /tmp/stb-ipc-demo.sock

# Terminal 2: WebProcess-side demo client
./build/stb_ipc_client /tmp/stb-ipc-demo.sock

# Optional C client example (server must be running)
./build/stb_ipc_c_client /tmp/stb-ipc-demo.sock
```

## 2. Public headers

| Header | Responsibility |
|---|---|
| `stbipc/Value.h` | Supported parameter types and `argAs<T>()` |
| `stbipc/Protocol.h` | Message structure, message/status enums, `encode()` and `decode()` |
| `stbipc/ApiIds.h` | Stable numeric class/API identifiers |
| `stbipc/UnixSocket.h` | Unix socket setup, frame I/O, and `SCM_RIGHTS` FD passing |
| `stbipc/SharedBuffer.h` | Linux `memfd` shared buffers and `mmap` helper |
| `stbipc/IpcClient.h` | C++ client request/reply, one-way calls and event callbacks |
| `stbipc/c_api.h` | C-compatible opaque client, typed values, callbacks and wrapper functions |
| `stbipc/IpcServer.h` | Server API registration and event emission |
| `stbipc/Services.h` | Demo service registration |


## 2A. C/C++ integration API (`stbipc/c_api.h`)

Use this API when the WebKit plugin or legacy/native interface layer is compiled as C, or when a C module must not depend on C++ types. The implementation is C++ internally; the public header is valid C and exposes an opaque `stbipc_client` handle.

### Build requirements

- Compile the calling source as C (`.c`); include only `#include "stbipc/c_api.h"`.
- Link the final executable with the C++ linker and the `stbipc` library because the implementation uses C++ runtime and threads. With CMake, `target_link_libraries(my_app PRIVATE stbipc)` normally propagates dependencies; for a C-only target, set `LINKER_LANGUAGE CXX` if CMake does not choose it automatically.
- Build the framework and C sample with the normal commands in section 1. The C sample target is `stb_ipc_c_client`.

### Core functions

| Function | Purpose / parameters | Return and ownership |
|---|---|---|
| `stbipc_client_create(socket_path)` | Create client; `socket_path` is copied | Client pointer, or `NULL`; inspect `stbipc_last_error()` |
| `stbipc_client_connect(client)` | Connect to Middleware socket and start event reader thread | `0` success, `-1` failure |
| `stbipc_client_disconnect(client)` | Stop client and wake pending calls | `void`; safe for `NULL` |
| `stbipc_client_is_connected(client)` | Check connection state | `1` connected, `0` otherwise |
| `stbipc_client_call(...)` | Sync request/reply; class/API IDs, typed argument array, argument count, timeout in ms | `0` success, `-1` failure; response array is caller-owned |
| `stbipc_client_send_oneway(...)` | Send without waiting for a reply | `0` success, `-1` failure |
| `stbipc_client_set_event_callback(...)` | Install callback and opaque `user_data`; pass `NULL` callback to clear | `0` success, `-1` failure |
| `stbipc_values_free(values, count)` | Free response array and owned string/byte payloads | Use only for arrays returned by `stbipc_client_call()` |
| `stbipc_last_error()` | Thread-local error text for the most recent API call on this thread | Borrowed string; copy it if it must outlive the next API call |
| `stbipc_client_destroy(client)` | Destroy client; disconnects through C++ destructor | `void`; safe for `NULL` |

`timeout_ms <= 0` uses the 3000 ms default. `response_args` and `response_count` must either both be non-NULL or both be NULL. When both are NULL, the call waits for success/failure but discards response arguments. The protocol supports up to 64 arguments.

### C value types

`stbipc_value` is a tagged union. Set `type` first, then populate the matching `as` member:

| `type` | `as` field | Notes |
|---|---|---|
| `STBIPC_VALUE_I32` | `i32` | `int32_t` |
| `STBIPC_VALUE_U32` | `u32` | `uint32_t` |
| `STBIPC_VALUE_I64` | `i64` | `int64_t` |
| `STBIPC_VALUE_U64` | `u64` | `uint64_t` |
| `STBIPC_VALUE_BOOL` | `boolean` | zero is false; nonzero is true |
| `STBIPC_VALUE_DOUBLE` | `real` | `double` |
| `STBIPC_VALUE_STRING` | `string` | NUL-terminated UTF-8/string data; input is borrowed during the call |
| `STBIPC_VALUE_BYTES` | `bytes.data`, `bytes.size` | Input is borrowed during the call; large media buffers should use FD passing instead |

### Example: DRM API with multiple parameters

The `SendLicense` contract is class ID `2`, API ID `1`, with `string xml`, `string systemID`, and `uint32 messageType`:

```c
#include "stbipc/c_api.h"
#include <stdio.h>

int send_license(stbipc_client *client, const char *xml,
                 const char *system_id, uint32_t message_type)
{
    stbipc_value args[3] = {0};
    args[0].type = STBIPC_VALUE_STRING; args[0].as.string = xml;
    args[1].type = STBIPC_VALUE_STRING; args[1].as.string = system_id;
    args[2].type = STBIPC_VALUE_U32;    args[2].as.u32 = message_type;

    stbipc_value *reply = NULL;
    size_t reply_count = 0;
    if (stbipc_client_call(client, 2, 1, args, 3, 3000,
                           &reply, &reply_count) != 0) {
        fprintf(stderr, "SendLicense failed: %s\n", stbipc_last_error());
        return -1;
    }

    /* Expected reply: bool accepted, string result (if implemented that way). */
    if (reply_count >= 2 && reply[0].type == STBIPC_VALUE_BOOL &&
        reply[1].type == STBIPC_VALUE_STRING) {
        printf("accepted=%d, result=%s\n", reply[0].as.boolean,
               reply[1].as.string);
    }
    stbipc_values_free(reply, reply_count);
    return 0;
}
```

### Event callback lifetime and threading

The callback receives `stbipc_event` with `class_id`, `api_id`, `request_id`, `args`, and `arg_count`. The `event`, `args`, and any string/byte data inside its values are borrowed and valid only until the callback returns. Copy anything that must be retained. Callbacks execute on the client's reader thread, so keep them short and thread-safe; do not block waiting for work that requires that same reader thread to process a reply. Do not call `stbipc_values_free()` on callback arguments.

C API functions return `0` on success and `-1` on failure unless documented otherwise. `stbipc_last_error()` is thread-local, so retrieve it on the same thread that received the failure. Inputs are copied/serialized before the function returns; caller retains ownership of input strings and bytes.

## 3. Typed parameters

`Value` is a `std::variant` supporting:

| C++ type | Wire type | Typical use |
|---|---|---|
| `std::int32_t` | `I32` | Signed counters/status values |
| `std::uint32_t` | `U32` | Channel IDs, message types, durations |
| `std::int64_t` | `I64` | Signed timestamps or large counters |
| `std::uint64_t` | `U64` | IDs and unsigned counters |
| `bool` | `Bool` | Flags such as autoplay |
| `double` | `Double` | Numeric values requiring floating point |
| `std::string` | `String` | URLs, DRM XML, system IDs, event names |
| `stbipc::Bytes` | `Bytes` | Small binary blobs or metadata |

An API can have zero or multiple arguments. The current protocol caps the argument count at 64 and the complete serialized frame at 4 MiB. Large media payloads should be sent through a shared buffer FD, not placed in `Bytes`.

### Typed extraction

```cpp
const auto& url = stbipc::argAs<std::string>(message.args, 0);
const bool autoplay = stbipc::argAs<bool>(message.args, 1);
```

`argAs<T>(args, index)`:

- `args`: decoded argument vector.
- `index`: zero-based argument position.
- Returns: `const T&` to the value in the vector.
- Throws `std::out_of_range` if the index is absent.
- Throws `std::invalid_argument` if the value has a different type.

Each registered handler must also validate the exact argument count and business-specific value ranges. `argAs<T>()` alone does not reject extra arguments.

## 4. Message and protocol APIs

### `Message`

Fields:

- `type`: `Request`, `Response`, `Event`, or `OneWay`.
- `requestId`: nonzero for request/reply correlation; use zero for events and one-way messages.
- `classId`, `apiId`: stable numeric route key.
- `status`: `Ok`, `InvalidArgument`, `NotFound`, `InternalError`, `Unsupported`, `Timeout`, or `Disconnected`.
- `args`: typed argument list.

### `encode(const Message&)`

Serializes a message to `std::vector<std::uint8_t>`. Throws `ProtocolError` for unsupported/oversized payloads.

### `decode(data, size)` / `decode(vector)`

Validates the protocol header/version and decodes typed arguments. Use the vector overload when consuming the output of `receiveFrame()`.

## 5. Unix socket APIs

### `connectUnix(path)`

Connects to an existing Unix domain socket. `path` is the filesystem socket path. Returns a connected FD or throws `std::runtime_error`.

### `listenUnix(path, backlog = 8)`

Creates, binds and listens on a filesystem Unix socket. `backlog` controls the pending connection queue. Returns the listening FD. The current demo removes an existing path before binding; in production, use a service-owned directory and verify ownership before unlinking any path.

### `acceptUnix(listenFd)`

Accepts one client and returns a close-on-exec client FD.

### `sendFrame(socketFd, payload)` / `receiveFrame(socketFd)`

Send or receive one length-prefixed frame. `payload` is serialized protocol data, usually `encode(message)`. The 4-byte frame length is little-endian. These ordinary-frame functions reject unexpected attached FDs (and close the received FD).

### `sendFrameWithFd(socketFd, payload, fdToSend)`

Sends a regular frame and transfers one open file descriptor using `sendmsg()` with `SCM_RIGHTS`.

- `socketFd`: connected `AF_UNIX` stream socket.
- `payload`: normal serialized IPC message; should include metadata describing the buffer, such as buffer size, usage, format, width/height and stride.
- `fdToSend`: open memfd/shared-memory FD or DMA-BUF FD. The sender retains its own FD; SCM_RIGHTS gives the receiver a new descriptor referring to the same underlying object.
- Returns: `void`; throws on send failure or invalid frame.

### `receiveFrameWithFd(socketFd)`

Receives one frame and optional attached descriptor. Returns `ReceivedFrame`:

- `payload`: decoded by the caller with `decode()`.
- `fd`: descriptor owned by the caller, or `-1` if no FD arrived.

The caller must close the returned FD. The current helper permits at most one FD per frame. A single-FD DMA-BUF is supported. Multi-plane DMA-BUFs that require multiple plane FDs need a bounded multi-FD extension and a documented plane layout.

**Important stream rule:** the ancillary FD is associated with the beginning of the frame. Do not read the socket with a separate `recv()` before calling `receiveFrameWithFd()`, or the FD may be separated from its frame. On a connection that carries FDs, all reads must go through the same framing/ancillary-data reader.

## 6. Shared-memory APIs

### `SharedBuffer::create(size, name = "stb-ipc-buffer")`

Creates a Linux `memfd` object and sizes it with `ftruncate()`.

- `size`: requested bytes; must be greater than zero and no more than 512 MiB in this prototype.
- `name`: diagnostic name visible in Linux process/memory tools; not a security boundary.
- Returns: move-only `SharedBuffer`, owning an FD and recording the size.

`buffer.fd()` borrows the FD; `buffer.size()` returns the size; `buffer.release()` transfers FD ownership to the caller; `buffer.reset()` closes the FD. The class is move-only to avoid accidental double-close.

### `mapSharedBuffer(fd, size, writable)`

Maps a received or locally owned buffer with `mmap(MAP_SHARED)`.

- `fd`: open FD for the shared memory/DMA buffer.
- `size`: requested mapping length. The helper checks that `fstat()` reports at least this many bytes and rejects sizes over the configured limit.
- `writable`: `true` maps read/write; `false` maps read-only.
- Returns: mapped address; caller must call `munmap(address, size)`.

The receiver must not trust a size supplied by the peer. Apply per-service limits and verify metadata before mapping. The sender and receiver must define who may read/write, when the producer has finished, when the consumer is done, and when the buffer may be reused. `SCM_RIGHTS` transfers a descriptor, not buffer ownership policy or synchronization.

### DMA-BUF note

`sendFrameWithFd()` can transfer a DMA-BUF FD exactly like a memfd. The framework does not allocate a DMA-BUF, import it into a graphics/media API, or manage fences. The media adapter must obtain the FD from the platform allocator/player, carry the format/plane metadata, use the appropriate importer, and coordinate fences/cache synchronization according to the platform's DMA-BUF contract. Do not assume a plain CPU `mmap()` is valid for every DMA-BUF.

## 7. Class/API IDs

`ApiIds.h` currently reserves these classes:

| Class | ID | Example APIs |
|---|---:|---|
| Player | 1 | `Play=1`, `Pause=2`, `GetState=3` |
| DRM | 2 | `SendLicense=1`, `OnMessageDrm=2` |
| Tuner | 3 | `Tune=1` |
| Recorder | 4 | `StartRecording=1` |
| EPG | 5 | `QueryNowNext=1`, `EpgEvent=2` |
| Plugin | 6 | `Notify=1` |

IDs are part of the wire contract. Do not renumber an ID already used by deployed peers. Document argument types, return types, call mode and compatibility whenever adding an API.

## 8. API contract examples

These are the demo's intended argument contracts; update the handlers and this table together when connecting product services.

| Class/API | Request arguments | Response/event arguments | Mode |
|---|---|---|---|
| Player `Play` | `string url`, `bool autoplay` | `string result` | Request/reply |
| Player `Pause` | none | none | Request/reply |
| Player `GetState` | none | `string state`, `uint32 stateCode` | Request/reply |
| DRM `SendLicense` | `string xml`, `string systemID`, `uint32 messageType` | `bool accepted`, `string result` | Request/reply |
| DRM `OnMessageDrm` | event-specific fields defined by product contract | event-specific fields | Event (define schema before use) |
| Tuner `Tune` | `uint32 channel` | `bool accepted` | Request/reply |
| Recorder `StartRecording` | `string recordingId`, `uint32 durationSeconds` | `string result` | Request/reply |
| EPG `QueryNowNext` | `uint32 serviceId` | `uint32 serviceId`, `string now`, `string next` | Request/reply |
| EPG `EpgEvent` | product-defined event fields | product-defined event fields | Event |
| Plugin `Notify` | `string eventName` | none | One-way |

For DRM XML, use a `std::string` for XML text and keep `systemID` and `messageType` as separate typed arguments. Never serialize a C++ pointer, native object layout, or raw struct with padding into the wire protocol.

## 9. Request/reply and event flow

1. Client builds a `Message` with `type=Request`, a unique nonzero `requestId`, `classId`, `apiId`, and typed `args`.
2. Client serializes it with `encode()` and sends it with `sendFrame()`.
3. Server decodes it and dispatches using `(classId, apiId)`.
4. Server returns a `Response` with the same `requestId` and route IDs.
5. Client matches the response to the waiting request. Events are delivered through the event callback and should not be mistaken for replies.

For buffer transfer, put the metadata in the protocol message and send that encoded message with `sendFrameWithFd()`. The receiver must use `receiveFrameWithFd()` for that frame, decode the metadata, validate it, map/import the FD, and close the received FD when finished.

## 10. Production checklist

- Place the socket in a service-owned directory and set restrictive permissions; authenticate peers with `SO_PEERCRED`.
- Add a version/capability handshake and per-API schema validation.
- Enforce per-API timeouts, cancellation, rate limits and bounded queues.
- Use a single coordinated reader for all frames and ancillary descriptors on each connection.
- Bound frame, string, byte-array and shared-buffer sizes. Reject invalid FDs, mismatched metadata and unexpected descriptors.
- Specify buffer lifetime/ownership, read/write roles, fences and reuse protocol; never reuse a buffer while the other process is consuming it.
- Test peer disconnect during transfer, malformed lengths, truncated ancillary data, unexpected/multiple FDs, undersized buffers and permission failures.
- Use a bounded worker pool and multi-client server if required by the product.
- Keep IPC reader callbacks short; dispatch events onto the WebProcess/plugin's appropriate thread.
- Replace mock services with real middleware adapters and perform end-to-end WebKitWPE integration tests.

## IPCClient blocking behavior and safe shutdown

`IpcClient` has both blocking and background behavior; it is **not a fully non-blocking API**:

| Operation | Can block? | Current behavior / safe use |
|---|---|---|
| `connect()` | Yes, during local Unix-socket connection setup | Call from initialization/worker context rather than a latency-sensitive WebKit main thread. Throws if the server is unavailable. |
| `call(...)` | Yes | Sends the request, then waits on a condition variable for a matching response up to the supplied timeout (default 3000 ms). Use from a worker thread, not the WebProcess main thread. |
| `sendOneWay(...)` | Yes, during socket send | Does not wait for a reply, but the send can block. The client socket configures `SO_SNDTIMEO` to 3 seconds; use a queued writer/worker if strict non-blocking caller latency is required. |
| Reader thread | Yes, intentionally, in `recv()` | Runs in the background and receives replies/events. `disconnect()` calls `shutdown()` to wake it. |
| Event callback | Runs synchronously on the reader thread | Keep it short. Marshal work to the WebKit/plugin event loop before touching thread-affine objects. Do not wait there for a reply that requires the same reader thread. |
| `disconnect()` | Normally returns promptly; joins the reader thread | Thread-safe and idempotent. It shuts down the socket, fails pending calls with `Disconnected`, waits for the reader from other threads, and leaves descriptor close to the reader thread to avoid descriptor-reuse races. |

The `call()` timeout specifically bounds the **reply wait**. A send can additionally take up to the configured socket send timeout, so total wall-clock time can exceed the reply timeout. Socket timeouts are not a substitute for keeping blocking calls off the WebProcess main thread.

### Client shutdown test

`tests/client_stop_test.cpp` verifies that disconnect wakes the reader and fails an outstanding synchronous request instead of making the caller wait for the full request timeout. Run it with:

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j4
ctest --test-dir build --output-on-failure
```

## 11. WebProcess lifecycle and blocking server loop

**Never call `examples/server_main.cpp`'s `main()` from a WebProcess constructor.** `IpcServer::run()` is a blocking server loop by design. The server belongs in the Middleware process; the WebProcess is the `IpcClient` side. Start the server with the Middleware service manager/product launcher, then create a client bridge from the WebProcess/plugin.

`examples/webprocess_constructor_safe.cpp` is a buildable reference pattern:

- The bridge constructor starts a worker thread and returns without waiting for a socket connection or API response.
- The worker creates/connects `IpcClient` and processes queued work.
- `postPlay()` / `postDrmLicense()` enqueue calls; synchronous IPC waits happen on the worker, not the WebKit main thread.
- The destructor signals shutdown and joins the worker.
- Event callbacks run on the IPC reader thread. In a real WebKit port, copy the event data and dispatch it onto the correct WebKit run loop; never touch WebKit objects directly from the reader thread.

Run it with the server in a separate terminal:

```sh
./build/stb_ipc_server /tmp/stb-ipc-demo.sock
./build/stb_ipc_webprocess_bridge /tmp/stb-ipc-demo.sock
```

The example's `main()` is only a standalone demo harness. For integration, own `WebProcessIpcBridge` in the plugin/process integration object's lifecycle and call its `post*` methods from API dispatch points. Do not create a second server from the WebProcess constructor.

## 11. Safe server shutdown and integration with an existing Middleware `main()`

`IpcServer::run()` is a blocking accept/dispatch loop by design. It belongs in the Middleware process, not the WebKitWPE WebProcess constructor. The server now provides:

- `stop()`: thread-safe and idempotent; interrupts a blocking client receive, wakes a blocking `accept()` using a local Unix-socket connection, and leaves final descriptor closure to the server thread.
- `waitUntilReady(timeout)`: waits until the listening socket is ready or startup has failed. This avoids a startup race when the WebProcess client connects immediately.
- Single-run protection: calling `run()` more than once on the same `IpcServer` throws `std::logic_error`.

### C-compatible lifecycle adapter

`include/stbipc/middleware_ipc.h` exposes:

```c
int middleware_ipc_start(const char *socket_path);
void middleware_ipc_stop(void);
```

The implementation is `src/MiddlewareIpcService.cpp`, built as the optional `stbipc_middleware_service` target. `middleware_ipc_start()` creates the server on a dedicated thread, waits up to three seconds for readiness, then returns. `middleware_ipc_stop()` requests shutdown and joins that thread before releasing the server.

Example usage inside your **existing Middleware** entry point:

```c
#include "stbipc/middleware_ipc.h"

int main(int argc, char **argv)
{
    /* Existing Middleware initialization. */
    if (middleware_ipc_start("/run/stb-ipc/middleware.sock") != 0) {
        /* Log and handle IPC startup failure. */
        return 1;
    }

    /* Existing Middleware event loop / operation continues here. */
    middleware_run();

    middleware_ipc_stop();
    /* Existing Middleware shutdown. */
    return 0;
}
```

`middleware_run()` is a placeholder for your product's existing run loop. The sample lifecycle adapter registers the demo services via `registerExampleServices()`; replace that call with your actual Player/DRM/Tuner/Recorder/EPG service registrations before product use. Link your existing Middleware target with `stbipc_middleware_service` and `stbipc`.

The WebKitWPE WebProcess must **not** call `middleware_ipc_start()`. It should instantiate/use `IpcClient` (or the C client wrapper), and should never run the server loop. During shutdown, stop the server before destroying the objects captured by registered API handlers. The server serially handles one client in this prototype; use a multi-client/worker design if the product requires concurrent clients.
