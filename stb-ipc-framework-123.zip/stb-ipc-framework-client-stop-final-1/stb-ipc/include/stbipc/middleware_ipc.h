#ifndef STBIPC_MIDDLEWARE_IPC_H
#define STBIPC_MIDDLEWARE_IPC_H

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Starts the IPC server on a dedicated thread and waits briefly for the
 * listening socket to become ready. Intended to be called by the existing
 * Middleware main(), not by the WebKit WebProcess.
 *
 * Returns 0 on success, -1 on invalid input/startup failure.
 */
int middleware_ipc_start(const char *socket_path);

/* Requests shutdown, wakes blocking accept/recv, joins the server thread,
 * and releases server resources. Safe to call repeatedly. */
void middleware_ipc_stop(void);

#ifdef __cplusplus
}
#endif

#endif /* STBIPC_MIDDLEWARE_IPC_H */
