#pragma once

#include "stbipc/Protocol.h"
#include "stbipc/UnixSocket.h"

#include <atomic>
#include <chrono>
#include <condition_variable>
#include <cstdint>
#include <functional>
#include <map>
#include <memory>
#include <mutex>
#include <string>
#include <thread>

namespace stbipc {

// Thread-safe request/reply client. call() waits for a reply and therefore
// must not be called from a latency-sensitive WebKit/WebProcess main thread.
// Incoming replies and events are received by the private reader thread.
class IpcClient {
public:
    using EventHandler = std::function<void(const Message&)>;

    explicit IpcClient(std::string socketPath);
    ~IpcClient();

    IpcClient(const IpcClient&) = delete;
    IpcClient& operator=(const IpcClient&) = delete;

    // connect() performs a local Unix-domain socket connect and starts the
    // reader thread. It can throw if the server is not listening.
    void connect();

    // Thread-safe and idempotent. Wakes a reader blocked in recv(), fails
    // outstanding requests, joins the reader (unless called by that thread),
    // and lets the reader own final descriptor close to avoid FD reuse races.
    void disconnect() noexcept;

    bool connected() const noexcept;

    // Blocking API: waits for the response up to timeout. The timeout bounds
    // response waiting, not arbitrary caller-thread scheduling delays. Socket
    // sends have a bounded SO_SNDTIMEO configured during connect().
    Message call(std::uint32_t classId, std::uint32_t apiId, Args args,
                 std::chrono::milliseconds timeout = std::chrono::milliseconds(3000));

    // Does not wait for a reply, but the socket send itself may wait up to the
    // configured send timeout. Use from a worker if strict non-blocking latency
    // is required; a queued async writer can be added for that requirement.
    void sendOneWay(std::uint32_t classId, std::uint32_t apiId, Args args);

    // The handler is invoked on the IPC reader thread. Dispatch to the proper
    // WebKit/plugin thread before touching thread-affine objects.
    void setEventHandler(EventHandler handler);

private:
    struct Pending {
        std::mutex mutex;
        std::condition_variable cv;
        bool done{false};
        Message response;
    };

    void readerLoop() noexcept;
    void failPending(Status status) noexcept;
    void closeSocketFromReader() noexcept;

    std::string path_;
    int fd_{-1};
    std::atomic<bool> running_{false};
    std::thread reader_;
    std::atomic<std::uint64_t> nextId_{1};

    // Lock order for sending/closing: sendMutex_ -> stateMutex_. disconnect()
    // only takes stateMutex_ while calling shutdown(), never close().
    mutable std::mutex stateMutex_;
    std::mutex sendMutex_;
    std::mutex pendingMutex_;
    std::mutex eventMutex_;
    std::map<std::uint64_t, std::shared_ptr<Pending>> pending_;
    EventHandler eventHandler_;
};

} // namespace stbipc
