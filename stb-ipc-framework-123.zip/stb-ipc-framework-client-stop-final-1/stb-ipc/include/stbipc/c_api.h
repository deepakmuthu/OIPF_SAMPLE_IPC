#ifndef STBIPC_C_API_H
#define STBIPC_C_API_H

/* Stable C ABI wrapper around the C++17 stbipc client.
 * Input strings/byte arrays are borrowed for the duration of the call.
 * Returned response values are owned by the caller and must be released with
 * stbipc_values_free(). Event callback values are borrowed and valid only
 * until the callback returns. All functions return 0 on success unless stated.
 */
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct stbipc_client stbipc_client;

typedef enum stbipc_value_type {
    STBIPC_VALUE_I32 = 1,
    STBIPC_VALUE_U32 = 2,
    STBIPC_VALUE_I64 = 3,
    STBIPC_VALUE_U64 = 4,
    STBIPC_VALUE_BOOL = 5,
    STBIPC_VALUE_DOUBLE = 6,
    STBIPC_VALUE_STRING = 7,
    STBIPC_VALUE_BYTES = 8
} stbipc_value_type;

typedef struct stbipc_value {
    stbipc_value_type type;
    union {
        int32_t i32;
        uint32_t u32;
        int64_t i64;
        uint64_t u64;
        int boolean; /* 0=false, nonzero=true */
        double real;
        const char *string;
        struct { const uint8_t *data; size_t size; } bytes;
    } as;
} stbipc_value;

typedef struct stbipc_event {
    uint64_t request_id;
    uint32_t class_id;
    uint32_t api_id;
    const stbipc_value *args; /* borrowed: callback lifetime only */
    size_t arg_count;
} stbipc_event;

typedef void (*stbipc_event_callback)(const stbipc_event *event, void *user_data);

/* Create/destroy an opaque client. socket_path is copied by the library. */
stbipc_client *stbipc_client_create(const char *socket_path);
void stbipc_client_destroy(stbipc_client *client);

int stbipc_client_connect(stbipc_client *client);
void stbipc_client_disconnect(stbipc_client *client);
int stbipc_client_is_connected(const stbipc_client *client);

/* Synchronous request/reply. timeout_ms <= 0 selects the default 3000 ms.
 * On success, response_args/response_count are caller-owned outputs. They may
 * be NULL only when response_count is NULL or no output is requested. */
int stbipc_client_call(stbipc_client *client,
                       uint32_t class_id,
                       uint32_t api_id,
                       const stbipc_value *args,
                       size_t arg_count,
                       int timeout_ms,
                       stbipc_value **response_args,
                       size_t *response_count);

/* Fire-and-forget one-way message; no response is awaited. */
int stbipc_client_send_oneway(stbipc_client *client,
                              uint32_t class_id,
                              uint32_t api_id,
                              const stbipc_value *args,
                              size_t arg_count);

/* Install/replace event callback. Pass NULL to clear it. */
int stbipc_client_set_event_callback(stbipc_client *client,
                                     stbipc_event_callback callback,
                                     void *user_data);

/* Free values returned by stbipc_client_call(). Safe on NULL. */
void stbipc_values_free(stbipc_value *values, size_t count);

/* Last error for the calling thread; pointer remains valid until the next
 * stbipc API call on that thread. Returns a non-empty fallback for NULL. */
const char *stbipc_last_error(void);

#ifdef __cplusplus
} /* extern "C" */
#endif
#endif /* STBIPC_C_API_H */
