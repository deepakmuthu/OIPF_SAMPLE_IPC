#pragma once

#include "stbipc/Protocol.h"
#include "stbipc/UnixSocket.h"

#include <atomic>
#include <chrono>
#include <condition_variable>
#include <cstdint>
#include <functional>
#include <map>
#include <mutex>
#include <string>

namespace stbipc {

using ApiHandler = std::function<Args(const Args&)>;

class IpcServer {
public:
    explicit IpcServer(std::string socketPath);
    ~IpcServer();

    IpcServer(const IpcServer&) = delete;
    IpcServer& operator=(const IpcServer&) = delete;

    void registerApi(std::uint32_t classId, std::uint32_t apiId, ApiHandler handler);

    // Blocking accept/dispatch loop. Run it on the Middleware thread or a
    // dedicated server thread, never on the WebKit WebProcess main thread.
    void run();

    // Thread-safe and idempotent. Wakes accept()/recv() so run() can return.
    // The run() thread owns final descriptor cleanup.
    void stop() noexcept;

    // Wait until the listening socket has been created or startup has failed.
    // Returns true only when the server became ready before the timeout.
    bool waitUntilReady(std::chrono::milliseconds timeout);

    void emitEvent(std::uint32_t classId, std::uint32_t apiId, Args args);

private:
    struct Key {
        std::uint32_t cls;
        std::uint32_t api;

        bool operator<(const Key& other) const noexcept
        {
            return cls < other.cls || (cls == other.cls && api < other.api);
        }
    };

    void handleClient(int clientFd);
    void closeClientFromRunThread(int clientFd) noexcept;
    void closeListenerFromRunThread() noexcept;

    std::string path_;
    std::atomic<bool> stopRequested_{false};
    std::atomic<bool> runStarted_{false};

    // Descriptor values are read/changed under fdMutex_. stop() uses shutdown
    // but leaves close() to the run thread, avoiding close/accept fd races.
    int listenFd_{-1};
    int clientFd_{-1};
    mutable std::mutex fdMutex_;

    std::map<Key, ApiHandler> handlers_;
    std::mutex handlerMutex_;
    std::mutex sendMutex_;

    std::mutex stateMutex_;
    std::condition_variable stateCv_;
    bool ready_{false};
    bool finished_{false};
    std::string startupError_;
};

} // namespace stbipc
