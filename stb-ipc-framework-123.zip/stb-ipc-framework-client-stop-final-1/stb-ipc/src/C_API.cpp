#include "stbipc/c_api.h"
#include "stbipc/IpcClient.h"
#include <cstdlib>
#include <cstring>
#include <memory>
#include <mutex>
#include <new>
#include <string>
#include <vector>

struct stbipc_client {
    explicit stbipc_client(const char *path) : impl(path) {}
    stbipc::IpcClient impl;
    std::mutex callback_mutex;
    stbipc_event_callback callback{nullptr};
    void *callback_data{nullptr};
};

namespace {
thread_local std::string g_last_error;
void clearError() { g_last_error.clear(); }
int fail(const char *message) { g_last_error = message ? message : "Unknown stbipc error"; return -1; }
int failException() {
    try { throw; }
    catch (const std::exception& e) { return fail(e.what()); }
    catch (...) { return fail("Unknown C++ exception in stbipc C API"); }
}

stbipc::Value toCpp(const stbipc_value& v) {
    switch (v.type) {
    case STBIPC_VALUE_I32: return v.as.i32;
    case STBIPC_VALUE_U32: return v.as.u32;
    case STBIPC_VALUE_I64: return v.as.i64;
    case STBIPC_VALUE_U64: return v.as.u64;
    case STBIPC_VALUE_BOOL: return v.as.boolean != 0;
    case STBIPC_VALUE_DOUBLE: return v.as.real;
    case STBIPC_VALUE_STRING:
        if (!v.as.string) throw std::invalid_argument("NULL string IPC argument");
        return std::string(v.as.string);
    case STBIPC_VALUE_BYTES:
        if (v.as.bytes.size && !v.as.bytes.data) throw std::invalid_argument("NULL byte buffer with nonzero size");
        if (v.as.bytes.size == 0) return stbipc::Bytes{};
        return stbipc::Bytes(v.as.bytes.data, v.as.bytes.data + v.as.bytes.size);
    default: throw std::invalid_argument("Unknown C IPC value type");
    }
}

stbipc::Args toCppArgs(const stbipc_value *args, size_t count) {
    if (count && !args) throw std::invalid_argument("NULL argument array with nonzero count");
    if (count > stbipc::kMaxArgs) throw std::invalid_argument("Too many IPC arguments (maximum 64)");
    stbipc::Args result;
    result.reserve(count);
    for (size_t i = 0; i < count; ++i) result.emplace_back(toCpp(args[i]));
    return result;
}

stbipc_value fromCpp(const stbipc::Value& value) {
    stbipc_value out{};
    if (const auto *p = std::get_if<int32_t>(&value)) { out.type=STBIPC_VALUE_I32; out.as.i32=*p; }
    else if (const auto *p = std::get_if<uint32_t>(&value)) { out.type=STBIPC_VALUE_U32; out.as.u32=*p; }
    else if (const auto *p = std::get_if<int64_t>(&value)) { out.type=STBIPC_VALUE_I64; out.as.i64=*p; }
    else if (const auto *p = std::get_if<uint64_t>(&value)) { out.type=STBIPC_VALUE_U64; out.as.u64=*p; }
    else if (const auto *p = std::get_if<bool>(&value)) { out.type=STBIPC_VALUE_BOOL; out.as.boolean=*p ? 1 : 0; }
    else if (const auto *p = std::get_if<double>(&value)) { out.type=STBIPC_VALUE_DOUBLE; out.as.real=*p; }
    else if (const auto *p = std::get_if<std::string>(&value)) {
        out.type=STBIPC_VALUE_STRING;
        auto *copy = static_cast<char*>(std::malloc(p->size()+1));
        if (!copy) throw std::bad_alloc();
        std::memcpy(copy,p->c_str(),p->size()+1); out.as.string=copy;
    } else if (const auto *p = std::get_if<stbipc::Bytes>(&value)) {
        out.type=STBIPC_VALUE_BYTES;
        uint8_t *copy = nullptr;
        if (!p->empty()) { copy=static_cast<uint8_t*>(std::malloc(p->size())); if (!copy) throw std::bad_alloc(); std::memcpy(copy,p->data(),p->size()); }
        out.as.bytes.data=copy; out.as.bytes.size=p->size();
    } else throw std::invalid_argument("Unsupported C++ IPC value type");
    return out;
}

void freeValueElements(stbipc_value *values, size_t count) {
    if (!values) return;
    for (size_t i=0;i<count;++i) {
        if (values[i].type==STBIPC_VALUE_STRING) std::free(const_cast<char*>(values[i].as.string));
        else if (values[i].type==STBIPC_VALUE_BYTES) std::free(const_cast<uint8_t*>(values[i].as.bytes.data));
    }
}

std::vector<stbipc_value> fromCppArgs(const stbipc::Args& args) {
    std::vector<stbipc_value> result;
    result.reserve(args.size());
    try { for (const auto& arg : args) result.emplace_back(fromCpp(arg)); }
    catch (...) { freeValueElements(result.data(), result.size()); throw; }
    return result;
}

void dispatchEvent(stbipc_client *client, const stbipc::Message& message) {
    stbipc_event_callback callback = nullptr;
    void *user_data = nullptr;
    { std::lock_guard<std::mutex> lock(client->callback_mutex); callback=client->callback; user_data=client->callback_data; }
    if (!callback) return;
    auto values = fromCppArgs(message.args);
    stbipc_event event{message.requestId, message.classId, message.apiId, values.data(), values.size()};
    callback(&event, user_data);
    freeValueElements(values.data(), values.size());
}
}

extern "C" {
stbipc_client *stbipc_client_create(const char *socket_path) {
    clearError();
    if (!socket_path || !*socket_path) { fail("socket_path must not be NULL or empty"); return nullptr; }
    try { return new stbipc_client(socket_path); } catch (...) { failException(); return nullptr; }
}
void stbipc_client_destroy(stbipc_client *client) { clearError(); delete client; }
int stbipc_client_connect(stbipc_client *client) {
    clearError(); if (!client) return fail("client is NULL");
    try {
        client->impl.setEventHandler([client](const stbipc::Message& m) { try { dispatchEvent(client,m); } catch (...) { /* never unwind into reader thread */ } });
        client->impl.connect(); return 0;
    } catch (...) { return failException(); }
}
void stbipc_client_disconnect(stbipc_client *client) { clearError(); if (client) client->impl.disconnect(); }
int stbipc_client_is_connected(const stbipc_client *client) { clearError(); return client && client->impl.connected() ? 1 : 0; }
int stbipc_client_call(stbipc_client *client, uint32_t class_id, uint32_t api_id,
                       const stbipc_value *args, size_t arg_count, int timeout_ms,
                       stbipc_value **response_args, size_t *response_count) {
    clearError();
    if (response_args) *response_args=nullptr;
    if (response_count) *response_count=0;
    if (!client) return fail("client is NULL");
    if ((response_args == nullptr) != (response_count == nullptr)) return fail("response_args and response_count must either both be NULL or both be non-NULL");
    try {
        auto request_args=toCppArgs(args,arg_count);
        const auto timeout=std::chrono::milliseconds(timeout_ms > 0 ? timeout_ms : 3000);
        auto response=client->impl.call(class_id,api_id,std::move(request_args),timeout);
        if (response_args && response_count) {
            auto values=fromCppArgs(response.args);
            if (!values.empty()) {
                auto *memory=static_cast<stbipc_value*>(std::malloc(values.size()*sizeof(stbipc_value)));
                if (!memory) { freeValueElements(values.data(),values.size()); throw std::bad_alloc(); }
                std::memcpy(memory,values.data(),values.size()*sizeof(stbipc_value));
                *response_args=memory; *response_count=values.size();
            }
            /* Transfer ownership of any heap strings/bytes to the returned array. */
            values.clear();
        }
        return 0;
    } catch (...) { return failException(); }
}
int stbipc_client_send_oneway(stbipc_client *client, uint32_t class_id, uint32_t api_id,
                              const stbipc_value *args, size_t arg_count) {
    clearError(); if (!client) return fail("client is NULL");
    try { client->impl.sendOneWay(class_id,api_id,toCppArgs(args,arg_count)); return 0; }
    catch (...) { return failException(); }
}
int stbipc_client_set_event_callback(stbipc_client *client, stbipc_event_callback callback, void *user_data) {
    clearError(); if (!client) return fail("client is NULL");
    { std::lock_guard<std::mutex> lock(client->callback_mutex); client->callback=callback; client->callback_data=user_data; }
    return 0;
}
void stbipc_values_free(stbipc_value *values, size_t count) {
    if (!values) return;
    freeValueElements(values,count);
    std::free(values);
}
const char *stbipc_last_error(void) { return g_last_error.empty() ? "No error" : g_last_error.c_str(); }
}
