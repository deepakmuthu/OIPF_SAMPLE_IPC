#include "stbipc/IpcClient.h"

#include <sys/socket.h>
#include <cerrno>
#include <cstring>
#include <stdexcept>
#include <string>
#include <utility>

namespace stbipc {
namespace {
constexpr std::chrono::seconds kSocketSendTimeout{3};

void configureSendTimeout(int fd)
{
    const timeval timeout{
        static_cast<time_t>(kSocketSendTimeout.count()), 0};
    if (::setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &timeout, sizeof(timeout)) < 0) {
        throw std::runtime_error(
            std::string("setsockopt(SO_SNDTIMEO) failed: ") + std::strerror(errno));
    }
}
} // namespace

IpcClient::IpcClient(std::string path)
    : path_(std::move(path))
{
}

IpcClient::~IpcClient()
{
    disconnect();
}

void IpcClient::connect()
{
    std::lock_guard<std::mutex> stateLock(stateMutex_);
    if (running_) {
        return;
    }
    if (reader_.joinable()) {
        throw std::logic_error("IPC reader thread must be joined before reconnecting");
    }

    int socketFd = connectUnix(path_);
    try {
        configureSendTimeout(socketFd);
        fd_ = socketFd;
        running_ = true;
        reader_ = std::thread(&IpcClient::readerLoop, this);
    } catch (...) {
        running_ = false;
        fd_ = -1;
        closeFd(socketFd);
        throw;
    }
}

void IpcClient::disconnect() noexcept
{
    running_ = false;
    {
        std::lock_guard<std::mutex> stateLock(stateMutex_);
        if (fd_ >= 0) {
            // shutdown() wakes a blocking receive. The reader thread closes fd_
            // after it exits, avoiding close/reuse races with recv()/send().
            (void)::shutdown(fd_, SHUT_RDWR);
        }
    }

    if (reader_.joinable() && reader_.get_id() != std::this_thread::get_id()) {
        reader_.join();
    }

    failPending(Status::Disconnected);
}

bool IpcClient::connected() const noexcept
{
    return running_.load();
}

Message IpcClient::call(
    std::uint32_t classId,
    std::uint32_t apiId,
    Args args,
    std::chrono::milliseconds timeout)
{
    if (!running_) {
        throw std::runtime_error("IPC client is not connected");
    }

    const auto requestId = nextId_++;
    auto pending = std::make_shared<Pending>();
    {
        std::lock_guard<std::mutex> lock(pendingMutex_);
        if (!running_) {
            throw std::runtime_error("IPC client is disconnecting");
        }
        pending_.emplace(requestId, pending);
    }

    Message request{
        MessageType::Request, requestId, classId, apiId, Status::Ok, std::move(args)};

    try {
        const auto bytes = encode(request);
        std::lock_guard<std::mutex> sendLock(sendMutex_);
        int socketFd = -1;
        {
            std::lock_guard<std::mutex> stateLock(stateMutex_);
            if (!running_ || fd_ < 0) {
                throw std::runtime_error("IPC client disconnected before send");
            }
            socketFd = fd_;
        }
        // sendMutex_ prevents the reader from closing/reusing this descriptor;
        // stateMutex_ is released so disconnect() can shutdown() a blocked send.
        sendFrame(socketFd, bytes);
    } catch (...) {
        {
            std::lock_guard<std::mutex> lock(pendingMutex_);
            pending_.erase(requestId);
        }
        throw;
    }

    std::unique_lock<std::mutex> lock(pending->mutex);
    if (!pending->cv.wait_for(lock, timeout, [&pending] { return pending->done; })) {
        lock.unlock();
        std::lock_guard<std::mutex> pendingLock(pendingMutex_);
        pending_.erase(requestId);
        throw std::runtime_error("IPC request timed out waiting for response");
    }

    if (pending->response.status != Status::Ok) {
        throw std::runtime_error(
            "IPC request failed with status " +
            std::to_string(static_cast<unsigned>(pending->response.status)));
    }
    return pending->response;
}

void IpcClient::sendOneWay(std::uint32_t classId, std::uint32_t apiId, Args args)
{
    if (!running_) {
        throw std::runtime_error("IPC client is not connected");
    }

    Message message{MessageType::OneWay, 0, classId, apiId, Status::Ok, std::move(args)};
    const auto bytes = encode(message);
    std::lock_guard<std::mutex> sendLock(sendMutex_);
    int socketFd = -1;
    {
        std::lock_guard<std::mutex> stateLock(stateMutex_);
        if (!running_ || fd_ < 0) {
            throw std::runtime_error("IPC client disconnected before send");
        }
        socketFd = fd_;
    }
    sendFrame(socketFd, bytes);
}

void IpcClient::setEventHandler(EventHandler handler)
{
    std::lock_guard<std::mutex> lock(eventMutex_);
    eventHandler_ = std::move(handler);
}

void IpcClient::failPending(Status status) noexcept
{
    std::map<std::uint64_t, std::shared_ptr<Pending>> pendingToFail;
    {
        std::lock_guard<std::mutex> pendingLock(pendingMutex_);
        pendingToFail.swap(pending_);
    }

    for (auto& entry : pendingToFail) {
        const auto& pending = entry.second;
        {
            std::lock_guard<std::mutex> itemLock(pending->mutex);
            if (!pending->done) {
                pending->done = true;
                pending->response.status = status;
            }
        }
        pending->cv.notify_all();
    }
}

void IpcClient::closeSocketFromReader() noexcept
{
    // Match send-side lock order. fd_ is never closed while another thread may
    // still be using it in sendFrame().
    std::lock_guard<std::mutex> sendLock(sendMutex_);
    std::lock_guard<std::mutex> stateLock(stateMutex_);
    closeFd(fd_);
}

void IpcClient::readerLoop() noexcept
{
    try {
        while (running_) {
            int socketFd = -1;
            {
                std::lock_guard<std::mutex> stateLock(stateMutex_);
                socketFd = fd_;
            }
            if (socketFd < 0 || !running_) {
                break;
            }

            auto message = decode(receiveFrame(socketFd));
            if (message.type == MessageType::Response) {
                std::shared_ptr<Pending> pending;
                {
                    std::lock_guard<std::mutex> lock(pendingMutex_);
                    const auto it = pending_.find(message.requestId);
                    if (it != pending_.end()) {
                        pending = it->second;
                        pending_.erase(it);
                    }
                }

                if (pending) {
                    {
                        std::lock_guard<std::mutex> lock(pending->mutex);
                        pending->response = std::move(message);
                        pending->done = true;
                    }
                    pending->cv.notify_all();
                }
            } else if (message.type == MessageType::Event) {
                EventHandler handler;
                {
                    std::lock_guard<std::mutex> lock(eventMutex_);
                    handler = eventHandler_;
                }
                if (handler) {
                    try {
                        handler(message);
                    } catch (...) {
                        // User callbacks must not terminate the IPC reader.
                    }
                }
            }
        }
    } catch (...) {
        running_ = false;
        failPending(Status::Disconnected);
    }

    running_ = false;
    failPending(Status::Disconnected);
    closeSocketFromReader();
}

} // namespace stbipc
