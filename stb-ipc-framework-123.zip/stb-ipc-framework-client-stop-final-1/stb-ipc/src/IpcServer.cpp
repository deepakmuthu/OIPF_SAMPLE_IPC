#include "stbipc/IpcServer.h"

#include <sys/socket.h>
#include <unistd.h>

#include <stdexcept>
#include <utility>

namespace stbipc {

IpcServer::IpcServer(std::string path)
    : path_(std::move(path))
{
}

IpcServer::~IpcServer()
{
    stop();
}

void IpcServer::registerApi(
    std::uint32_t classId,
    std::uint32_t apiId,
    ApiHandler handler)
{
    std::lock_guard<std::mutex> lock(handlerMutex_);
    handlers_[Key{classId, apiId}] = std::move(handler);
}

bool IpcServer::waitUntilReady(std::chrono::milliseconds timeout)
{
    std::unique_lock<std::mutex> lock(stateMutex_);
    stateCv_.wait_for(lock, timeout, [this] {
        return ready_ || finished_;
    });
    return ready_ && startupError_.empty() && !stopRequested_.load();
}

void IpcServer::run()
{
    bool expected = false;
    if (!runStarted_.compare_exchange_strong(expected, true)) {
        throw std::logic_error("IpcServer::run() may only be called once");
    }

    try {
        if (stopRequested_.load()) {
            std::lock_guard<std::mutex> lock(stateMutex_);
            finished_ = true;
            stateCv_.notify_all();
            return;
        }

        const int listener = listenUnix(path_);
        {
            std::lock_guard<std::mutex> lock(fdMutex_);
            listenFd_ = listener;
            if (stopRequested_.load()) {
                (void)::shutdown(listenFd_, SHUT_RDWR);
            }
        }
        {
            std::lock_guard<std::mutex> lock(stateMutex_);
            ready_ = !stopRequested_.load();
            stateCv_.notify_all();
        }

        while (!stopRequested_.load()) {
            int listenerFd = -1;
            {
                std::lock_guard<std::mutex> lock(fdMutex_);
                listenerFd = listenFd_;
            }
            if (listenerFd < 0) {
                break;
            }

            int acceptedFd = -1;
            try {
                acceptedFd = acceptUnix(listenerFd);
            } catch (const std::exception&) {
                if (stopRequested_.load()) {
                    break;
                }
                throw;
            }

            {
                std::lock_guard<std::mutex> lock(fdMutex_);
                clientFd_ = acceptedFd;
                if (stopRequested_.load()) {
                    (void)::shutdown(clientFd_, SHUT_RDWR);
                }
            }

            if (!stopRequested_.load()) {
                handleClient(acceptedFd);
            }
            closeClientFromRunThread(acceptedFd);
        }
    } catch (const std::exception& error) {
        const bool shouldRethrow = !stopRequested_.load();
        {
            std::lock_guard<std::mutex> lock(stateMutex_);
            if (!ready_) {
                startupError_ = error.what();
            }
            finished_ = true;
            stateCv_.notify_all();
        }
        closeClientFromRunThread(-1);
        closeListenerFromRunThread();
        if (shouldRethrow) {
            throw;
        }
        return;
    }

    closeClientFromRunThread(-1);
    closeListenerFromRunThread();
    {
        std::lock_guard<std::mutex> lock(stateMutex_);
        finished_ = true;
        stateCv_.notify_all();
    }
}

void IpcServer::stop() noexcept
{
    stopRequested_.store(true);

    // Interrupt a blocking receive on the active client. The run thread owns
    // close(), so stop() never closes a descriptor that the I/O thread may be
    // using (and therefore cannot trigger descriptor-reuse races).
    {
        std::lock_guard<std::mutex> lock(fdMutex_);
        if (clientFd_ >= 0) {
            (void)::shutdown(clientFd_, SHUT_RDWR);
        }
    }

    // A shutdown() on a listening AF_UNIX socket is not a portable/reliable
    // way to wake accept(). Connect once to our own socket instead. The run
    // thread sees stopRequested_, closes this wake-up client, and exits.
    try {
        const int wakeFd = connectUnix(path_);
        int fd = wakeFd;
        closeFd(fd);
    } catch (...) {
        // Expected if startup never reached listen(); the run loop also checks
        // stopRequested_ before entering accept().
    }
    stateCv_.notify_all();
}

void IpcServer::closeClientFromRunThread(int clientFd) noexcept
{
    std::lock_guard<std::mutex> sendLock(sendMutex_);
    std::lock_guard<std::mutex> fdLock(fdMutex_);

    const int fdToClose = (clientFd >= 0) ? clientFd : clientFd_;
    if (fdToClose >= 0) {
        (void)::shutdown(fdToClose, SHUT_RDWR);
        (void)::close(fdToClose);
    }
    if (clientFd_ == fdToClose) {
        clientFd_ = -1;
    }
}

void IpcServer::closeListenerFromRunThread() noexcept
{
    std::lock_guard<std::mutex> lock(fdMutex_);
    if (listenFd_ >= 0) {
        (void)::shutdown(listenFd_, SHUT_RDWR);
        (void)::close(listenFd_);
        listenFd_ = -1;
    }
    (void)::unlink(path_.c_str());
}

void IpcServer::emitEvent(
    std::uint32_t classId,
    std::uint32_t apiId,
    Args args)
{
    Message event{
        MessageType::Event,
        0,
        classId,
        apiId,
        Status::Ok,
        std::move(args)};
    const auto bytes = encode(event);

    // Keep the send lock while reading and using clientFd_: the run thread
    // takes the same lock before closing it.
    std::lock_guard<std::mutex> sendLock(sendMutex_);
    int fd = -1;
    {
        std::lock_guard<std::mutex> fdLock(fdMutex_);
        fd = clientFd_;
    }
    if (fd < 0 || stopRequested_.load()) {
        return;
    }
    sendFrame(fd, bytes);
}

void IpcServer::handleClient(int fd)
{
    while (!stopRequested_.load()) {
        Message request;
        try {
            request = decode(receiveFrame(fd));
        } catch (...) {
            break;
        }

        if (request.type != MessageType::Request &&
            request.type != MessageType::OneWay) {
            break;
        }

        Message response{
            MessageType::Response,
            request.requestId,
            request.classId,
            request.apiId,
            Status::Ok,
            {}};

        try {
            ApiHandler handler;
            {
                std::lock_guard<std::mutex> lock(handlerMutex_);
                const auto it = handlers_.find(Key{request.classId, request.apiId});
                if (it == handlers_.end()) {
                    throw std::out_of_range("API not registered");
                }
                handler = it->second;
            }
            response.args = handler(request.args);
        } catch (const std::invalid_argument&) {
            response.status = Status::InvalidArgument;
        } catch (const std::out_of_range&) {
            response.status = Status::NotFound;
        } catch (...) {
            response.status = Status::InternalError;
        }

        if (request.type == MessageType::Request) {
            try {
                const auto bytes = encode(response);
                std::lock_guard<std::mutex> sendLock(sendMutex_);
                if (stopRequested_.load()) {
                    break;
                }
                sendFrame(fd, bytes);
            } catch (...) {
                break;
            }
        }
    }
}

} // namespace stbipc
