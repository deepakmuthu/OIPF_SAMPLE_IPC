#include "stbipc/middleware_ipc.h"

#include "stbipc/IpcServer.h"
#include "stbipc/Services.h"

#include <chrono>
#include <memory>
#include <mutex>
#include <string>
#include <thread>

namespace {
std::mutex g_serviceMutex;
std::unique_ptr<stbipc::IpcServer> g_server;
std::thread g_serverThread;
constexpr auto kStartupTimeout = std::chrono::seconds(3);
}

extern "C" int middleware_ipc_start(const char *socket_path)
{
    if (socket_path == nullptr || socket_path[0] == '\0') {
        return -1;
    }

    std::lock_guard<std::mutex> lock(g_serviceMutex);
    if (g_server) {
        return 0; // Idempotent: service has already been started.
    }

    try {
        auto server = std::make_unique<stbipc::IpcServer>(socket_path);
        stbipc::registerExampleServices(*server);
        auto *serverPtr = server.get();

        std::thread worker([serverPtr]() {
            try {
                serverPtr->run();
            } catch (...) {
                // run() records startup failure for waitUntilReady(). Never
                // allow an exception to escape the std::thread entry point.
            }
        });

        if (!serverPtr->waitUntilReady(kStartupTimeout)) {
            serverPtr->stop();
            if (worker.joinable()) {
                worker.join();
            }
            return -1;
        }

        g_server = std::move(server);
        g_serverThread = std::move(worker);
        return 0;
    } catch (...) {
        return -1;
    }
}

extern "C" void middleware_ipc_stop(void)
{
    std::lock_guard<std::mutex> lock(g_serviceMutex);
    if (g_server) {
        g_server->stop();
    }
    if (g_serverThread.joinable()) {
        g_serverThread.join();
    }
    g_server.reset();
}
