#include "stbipc/middleware_ipc.h"

#include "stbipc/IpcServer.h"
#include "stbipc/Services.h"

#include <chrono>
#include <cstdlib>
#include <cstring>
#include <memory>
#include <mutex>
#include <new>
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>

namespace {
std::mutex g_serviceMutex;
std::shared_ptr<stbipc::IpcServer> g_server;
std::thread g_serverThread;
constexpr auto kStartupTimeout = std::chrono::seconds(3);

stbipc::Value toCppValue(const stbipc_value& value)
{
    switch (value.type) {
    case STBIPC_VALUE_I32: return value.as.i32;
    case STBIPC_VALUE_U32: return value.as.u32;
    case STBIPC_VALUE_I64: return value.as.i64;
    case STBIPC_VALUE_U64: return value.as.u64;
    case STBIPC_VALUE_BOOL: return value.as.boolean != 0;
    case STBIPC_VALUE_DOUBLE: return value.as.real;
    case STBIPC_VALUE_STRING:
        if (!value.as.string) throw std::invalid_argument("NULL string argument");
        return std::string(value.as.string);
    case STBIPC_VALUE_BYTES:
        if (value.as.bytes.size != 0 && value.as.bytes.data == nullptr)
            throw std::invalid_argument("NULL bytes pointer with non-zero size");
        if (value.as.bytes.size == 0) return stbipc::Bytes{};
        return stbipc::Bytes(value.as.bytes.data, value.as.bytes.data + value.as.bytes.size);
    default: throw std::invalid_argument("unknown C IPC value type");
    }
}

stbipc::Args toCppArgs(const stbipc_value* args, size_t count)
{
    if (count != 0 && args == nullptr) throw std::invalid_argument("NULL argument array");
    if (count > stbipc::kMaxArgs) throw std::invalid_argument("too many IPC arguments");
    stbipc::Args result;
    result.reserve(count);
    for (size_t i = 0; i < count; ++i) result.emplace_back(toCppValue(args[i]));
    return result;
}

stbipc_value fromCppValue(const stbipc::Value& value)
{
    stbipc_value out{};
    if (const auto* p = std::get_if<std::int32_t>(&value)) { out.type = STBIPC_VALUE_I32; out.as.i32 = *p; }
    else if (const auto* p = std::get_if<std::uint32_t>(&value)) { out.type = STBIPC_VALUE_U32; out.as.u32 = *p; }
    else if (const auto* p = std::get_if<std::int64_t>(&value)) { out.type = STBIPC_VALUE_I64; out.as.i64 = *p; }
    else if (const auto* p = std::get_if<std::uint64_t>(&value)) { out.type = STBIPC_VALUE_U64; out.as.u64 = *p; }
    else if (const auto* p = std::get_if<bool>(&value)) { out.type = STBIPC_VALUE_BOOL; out.as.boolean = *p ? 1 : 0; }
    else if (const auto* p = std::get_if<double>(&value)) { out.type = STBIPC_VALUE_DOUBLE; out.as.real = *p; }
    else if (const auto* p = std::get_if<std::string>(&value)) {
        out.type = STBIPC_VALUE_STRING;
        auto* copy = static_cast<char*>(std::malloc(p->size() + 1));
        if (!copy) throw std::bad_alloc();
        std::memcpy(copy, p->c_str(), p->size() + 1); out.as.string = copy;
    } else if (const auto* p = std::get_if<stbipc::Bytes>(&value)) {
        out.type = STBIPC_VALUE_BYTES;
        auto* copy = p->empty() ? nullptr : static_cast<std::uint8_t*>(std::malloc(p->size()));
        if (!p->empty() && !copy) throw std::bad_alloc();
        if (copy) std::memcpy(copy, p->data(), p->size());
        out.as.bytes.data = copy; out.as.bytes.size = p->size();
    } else throw std::invalid_argument("unsupported C++ IPC value");
    return out;
}

void freeValues(stbipc_value* values, size_t count) noexcept
{
    if (!values) return;
    for (size_t i = 0; i < count; ++i) {
        if (values[i].type == STBIPC_VALUE_STRING) std::free(const_cast<char*>(values[i].as.string));
        else if (values[i].type == STBIPC_VALUE_BYTES) std::free(const_cast<std::uint8_t*>(values[i].as.bytes.data));
    }
}

std::vector<stbipc_value> fromCppArgs(const stbipc::Args& args)
{
    std::vector<stbipc_value> result;
    result.reserve(args.size());
    try { for (const auto& value : args) result.push_back(fromCppValue(value)); }
    catch (...) { freeValues(result.data(), result.size()); throw; }
    return result;
}

std::shared_ptr<stbipc::IpcServer> getServer()
{
    std::lock_guard<std::mutex> lock(g_serviceMutex);
    return g_server;
}
} // namespace

extern "C" int middleware_ipc_start(const char *socket_path)
{
    if (socket_path == nullptr || socket_path[0] == '\0') return -1;
    std::lock_guard<std::mutex> lock(g_serviceMutex);
    if (g_server) return 0; // Idempotent start.

    try {
        auto server = std::make_shared<stbipc::IpcServer>(socket_path);
        stbipc::registerExampleServices(*server);
        std::thread worker([server]() {
            try { server->run(); }
            catch (...) { /* Never allow an exception to escape the thread entry point. */ }
        });
        if (!server->waitUntilReady(kStartupTimeout)) {
            server->stop();
            if (worker.joinable()) worker.join();
            return -1;
        }
        g_server = std::move(server);
        g_serverThread = std::move(worker);
        return 0;
    } catch (...) {
        return -1;
    }
}

extern "C" void middleware_ipc_stop(void)
{
    // Never hold g_serviceMutex while joining: a running API callback may need
    // getServer() to finish a bounded callClient() and would otherwise deadlock.
    std::shared_ptr<stbipc::IpcServer> server;
    std::thread serverThread;
    {
        std::lock_guard<std::mutex> lock(g_serviceMutex);
        server = std::move(g_server);
        serverThread = std::move(g_serverThread);
    }
    if (server) server->stop();
    if (serverThread.joinable()) serverThread.join();
}

extern "C" int middleware_ipc_register_api(uint32_t class_id, uint32_t api_id,
                                             stbipc_api_callback callback, void *user_data)
{
    if (!callback) return -1;
    auto server = getServer();
    if (!server) return -1;
    try {
        server->registerApi(class_id, api_id,
            [callback, user_data, class_id, api_id](const stbipc::Args& args) -> stbipc::Args {
                auto input = fromCppArgs(args);
                stbipc_event request{0, class_id, api_id, input.data(), input.size()};
                stbipc_value* output = nullptr;
                size_t outputCount = 0;
                try {
                    if (callback(&request, &output, &outputCount, user_data) != 0)
                        throw std::runtime_error("C Middleware API callback returned failure");
                    if (outputCount > stbipc::kMaxArgs || (outputCount != 0 && output == nullptr))
                        throw std::invalid_argument("C Middleware API callback returned invalid outputs");
                    auto result = toCppArgs(output, outputCount);
                    freeValues(output, outputCount);
                    std::free(output);
                    freeValues(input.data(), input.size());
                    return result;
                } catch (...) {
                    if (output) {
                        freeValues(output, outputCount <= stbipc::kMaxArgs ? outputCount : 0);
                        std::free(output);
                    }
                    freeValues(input.data(), input.size());
                    throw;
                }
            });
        return 0;
    } catch (...) {
        return -1;
    }
}

extern "C" int middleware_ipc_call_client(uint32_t class_id, uint32_t api_id,
                                            const stbipc_value *args, size_t arg_count,
                                            int timeout_ms, stbipc_value **response_args,
                                            size_t *response_count)
{
    if (response_args) *response_args = nullptr;
    if (response_count) *response_count = 0;
    if ((response_args == nullptr) != (response_count == nullptr)) return -1;
    auto server = getServer();
    if (!server) return -1;
    try {
        auto requestArgs = toCppArgs(args, arg_count);
        auto response = server->callClient(class_id, api_id, std::move(requestArgs),
            std::chrono::milliseconds(timeout_ms > 0 ? timeout_ms : 3000));
        if (response_args && response_count) {
            auto values = fromCppArgs(response.args);
            if (!values.empty()) {
                auto* memory = static_cast<stbipc_value*>(std::malloc(values.size() * sizeof(stbipc_value)));
                if (!memory) { freeValues(values.data(), values.size()); throw std::bad_alloc(); }
                std::memcpy(memory, values.data(), values.size() * sizeof(stbipc_value));
                *response_args = memory;
                *response_count = values.size();
            }
            values.clear(); // Ownership of nested strings/bytes moved to caller.
        }
        return 0;
    } catch (...) {
        return -1;
    }
}
