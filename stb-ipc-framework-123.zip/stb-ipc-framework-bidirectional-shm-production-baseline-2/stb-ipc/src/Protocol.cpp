#include "stbipc/Protocol.h"

#include <cstring>
#include <limits>
#include <type_traits>

namespace stbipc {

ValueType typeOf(const Value& value)
{
    return static_cast<ValueType>(value.index() + 1);
}

const char* typeName(ValueType type) noexcept
{
    switch (type) {
    case ValueType::I32:    return "int32";
    case ValueType::U32:    return "uint32";
    case ValueType::I64:    return "int64";
    case ValueType::U64:    return "uint64";
    case ValueType::Bool:   return "bool";
    case ValueType::Double: return "double";
    case ValueType::String: return "string";
    case ValueType::Bytes:  return "bytes";
    }
    return "unknown";
}

namespace {

void put(std::vector<std::uint8_t>& buffer, std::uint64_t value, unsigned byteCount)
{
    for (unsigned i = 0; i < byteCount; ++i) {
        buffer.push_back(static_cast<std::uint8_t>((value >> (8U * i)) & 0xffU));
    }
}

std::uint64_t get(const std::uint8_t*& cursor, const std::uint8_t* end, unsigned byteCount)
{
    if (static_cast<std::size_t>(end - cursor) < byteCount) {
        throw ProtocolError("truncated protocol field");
    }

    std::uint64_t value = 0;
    for (unsigned i = 0; i < byteCount; ++i) {
        value |= static_cast<std::uint64_t>(*cursor++) << (8U * i);
    }
    return value;
}

void putString(std::vector<std::uint8_t>& buffer, const std::string& value)
{
    if (value.size() > kMaxStringBytes) {
        throw ProtocolError("string exceeds limit");
    }

    put(buffer, value.size(), 4);
    buffer.insert(buffer.end(), value.begin(), value.end());
}

std::string getString(const std::uint8_t*& cursor, const std::uint8_t* end)
{
    const auto length = get(cursor, end, 4);
    if (length > kMaxStringBytes || length > static_cast<std::uint64_t>(end - cursor)) {
        throw ProtocolError("invalid string length");
    }

    std::string value(reinterpret_cast<const char*>(cursor), static_cast<std::size_t>(length));
    cursor += length;
    return value;
}

} // namespace

std::vector<std::uint8_t> encode(const Message& message)
{
    if (message.args.size() > kMaxArgs) {
        throw ProtocolError("too many arguments");
    }

    std::vector<std::uint8_t> buffer;
    buffer.reserve(64);
    put(buffer, kMagic, 4);
    put(buffer, kProtocolVersion, 2);
    put(buffer, static_cast<std::uint8_t>(message.type), 1);
    put(buffer, 0, 1);
    put(buffer, message.requestId, 8);
    put(buffer, message.classId, 4);
    put(buffer, message.apiId, 4);
    put(buffer, static_cast<std::uint16_t>(message.status), 2);
    put(buffer, message.args.size(), 2);

    for (const auto& argument : message.args) {
        put(buffer, static_cast<std::uint8_t>(typeOf(argument)), 1);
        put(buffer, 0, 1);
        put(buffer, 0, 2);

        std::visit(
            [&](const auto& value) {
                using T = std::decay_t<decltype(value)>;

                if constexpr (std::is_same_v<T, std::int32_t>) {
                    put(buffer, static_cast<std::uint32_t>(value), 4);
                } else if constexpr (std::is_same_v<T, std::uint32_t>) {
                    put(buffer, value, 4);
                } else if constexpr (std::is_same_v<T, std::int64_t>) {
                    put(buffer, static_cast<std::uint64_t>(value), 8);
                } else if constexpr (std::is_same_v<T, std::uint64_t>) {
                    put(buffer, value, 8);
                } else if constexpr (std::is_same_v<T, bool>) {
                    put(buffer, value ? 1 : 0, 1);
                } else if constexpr (std::is_same_v<T, double>) {
                    std::uint64_t bits;
                    static_assert(sizeof(bits) == sizeof(value));
                    std::memcpy(&bits, &value, sizeof(bits));
                    put(buffer, bits, 8);
                } else if constexpr (std::is_same_v<T, std::string>) {
                    putString(buffer, value);
                } else if constexpr (std::is_same_v<T, Bytes>) {
                    if (value.size() > kMaxFrameBytes) {
                        throw ProtocolError("byte array exceeds limit");
                    }
                    put(buffer, value.size(), 4);
                    buffer.insert(buffer.end(), value.begin(), value.end());
                }
            },
            argument);

        if (buffer.size() > kMaxFrameBytes) {
            throw ProtocolError("frame exceeds limit");
        }
    }

    if (buffer.size() > kMaxFrameBytes) {
        throw ProtocolError("frame exceeds limit");
    }
    return buffer;
}

Message decode(const std::uint8_t* data, std::size_t size)
{
    if (size > kMaxFrameBytes) {
        throw ProtocolError("frame exceeds limit");
    }

    const auto* cursor = data;
    const auto* end = data + size;
    if (get(cursor, end, 4) != kMagic) {
        throw ProtocolError("bad protocol magic");
    }
    if (get(cursor, end, 2) != kProtocolVersion) {
        throw ProtocolError("unsupported protocol version");
    }

    Message message;
    const auto messageType = get(cursor, end, 1);
    if (messageType < 1 || messageType > 4) {
        throw ProtocolError("invalid message type");
    }
    message.type = static_cast<MessageType>(messageType);
    (void)get(cursor, end, 1);

    message.requestId = get(cursor, end, 8);
    message.classId = static_cast<std::uint32_t>(get(cursor, end, 4));
    message.apiId = static_cast<std::uint32_t>(get(cursor, end, 4));
    message.status = static_cast<Status>(get(cursor, end, 2));
    const auto argumentCount = get(cursor, end, 2);
    if (argumentCount > kMaxArgs) {
        throw ProtocolError("too many arguments");
    }

    for (std::uint64_t i = 0; i < argumentCount; ++i) {
        const auto type = static_cast<ValueType>(get(cursor, end, 1));
        (void)get(cursor, end, 1);
        (void)get(cursor, end, 2);

        switch (type) {
        case ValueType::I32:
            message.args.emplace_back(static_cast<std::int32_t>(get(cursor, end, 4)));
            break;
        case ValueType::U32:
            message.args.emplace_back(static_cast<std::uint32_t>(get(cursor, end, 4)));
            break;
        case ValueType::I64:
            message.args.emplace_back(static_cast<std::int64_t>(get(cursor, end, 8)));
            break;
        case ValueType::U64:
            message.args.emplace_back(get(cursor, end, 8));
            break;
        case ValueType::Bool: {
            const auto value = get(cursor, end, 1);
            if (value > 1) {
                throw ProtocolError("invalid bool");
            }
            message.args.emplace_back(value != 0);
            break;
        }
        case ValueType::Double: {
            const auto bits = get(cursor, end, 8);
            double value;
            std::memcpy(&value, &bits, sizeof(value));
            message.args.emplace_back(value);
            break;
        }
        case ValueType::String:
            message.args.emplace_back(getString(cursor, end));
            break;
        case ValueType::Bytes: {
            const auto length = get(cursor, end, 4);
            if (length > kMaxFrameBytes ||
                length > static_cast<std::uint64_t>(end - cursor)) {
                throw ProtocolError("invalid byte array length");
            }
            Bytes value(cursor, cursor + length);
            cursor += length;
            message.args.emplace_back(std::move(value));
            break;
        }
        default:
            throw ProtocolError("unknown value type");
        }
    }

    if (cursor != end) {
        throw ProtocolError("trailing bytes in frame");
    }
    return message;
}

Message decode(const std::vector<std::uint8_t>& buffer)
{
    return decode(buffer.data(), buffer.size());
}

} // namespace stbipc
