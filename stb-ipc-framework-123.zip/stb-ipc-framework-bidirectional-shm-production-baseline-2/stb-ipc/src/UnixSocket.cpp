#include "stbipc/UnixSocket.h"
#include "stbipc/Protocol.h"
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <cerrno>
#include <cstring>
#include <stdexcept>
#include <cstdio>
#include <algorithm>
#include <cstddef>
#include <array>

namespace stbipc {
namespace {
void writeAll(int fd,const std::uint8_t* p,std::size_t n) {
    while(n) {
        auto r=::send(fd,p,n,MSG_NOSIGNAL);
        if(r<0&&errno==EINTR) continue;
        if(r<=0) throw std::runtime_error(std::string("socket send failed: ")+std::strerror(errno));
        p+=r; n-=static_cast<std::size_t>(r);
    }
}
void readAll(int fd,std::uint8_t* p,std::size_t n) {
    while(n) {
        auto r=::recv(fd,p,n,0);
        if(r<0&&errno==EINTR) continue;
        if(r==0) throw std::runtime_error("peer disconnected");
        if(r<0) throw std::runtime_error(std::string("socket receive failed: ")+std::strerror(errno));
        p+=r; n-=static_cast<std::size_t>(r);
    }
}
int makeAddress(const std::string& path,sockaddr_un& addr) {
    if(path.empty()||path.size()>=sizeof(addr.sun_path)) throw std::invalid_argument("Unix socket path is empty or too long");
    std::memset(&addr,0,sizeof(addr)); addr.sun_family=AF_UNIX;
    std::strncpy(addr.sun_path,path.c_str(),sizeof(addr.sun_path)-1);
    return static_cast<int>(offsetof(sockaddr_un,sun_path)+path.size()+1);
}
std::array<std::uint8_t,4> frameHeader(std::size_t size) {
    if(size==0||size>kMaxFrameBytes) throw ProtocolError("invalid frame size");
    const auto n=static_cast<std::uint32_t>(size);
    return {static_cast<std::uint8_t>(n),static_cast<std::uint8_t>(n>>8U),static_cast<std::uint8_t>(n>>16U),static_cast<std::uint8_t>(n>>24U)};
}
std::uint32_t parseLength(const std::uint8_t h[4]) {
    const std::uint32_t n=static_cast<std::uint32_t>(h[0]) |
        (static_cast<std::uint32_t>(h[1])<<8U) |
        (static_cast<std::uint32_t>(h[2])<<16U) |
        (static_cast<std::uint32_t>(h[3])<<24U);
    if(n==0||n>kMaxFrameBytes) throw ProtocolError("invalid frame length");
    return n;
}
}
int connectUnix(const std::string& path) {
    sockaddr_un a{}; int len=makeAddress(path,a); int fd=::socket(AF_UNIX,SOCK_STREAM|SOCK_CLOEXEC,0);
    if(fd<0) throw std::runtime_error("socket() failed");
    if(::connect(fd,reinterpret_cast<sockaddr*>(&a),static_cast<socklen_t>(len))<0) { auto e=errno; ::close(fd); throw std::runtime_error(std::string("connect() failed: ")+std::strerror(e)); }
    return fd;
}
int listenUnix(const std::string& path,int backlog) {
    sockaddr_un a{}; int len=makeAddress(path,a); ::unlink(path.c_str()); int fd=::socket(AF_UNIX,SOCK_STREAM|SOCK_CLOEXEC,0);
    if(fd<0) throw std::runtime_error("socket() failed");
    if(::bind(fd,reinterpret_cast<sockaddr*>(&a),static_cast<socklen_t>(len))<0||::listen(fd,backlog)<0) { auto e=errno; ::close(fd); throw std::runtime_error(std::string("bind/listen failed: ")+std::strerror(e)); }
    return fd;
}
int acceptUnix(int fd) { for(;;) { int c=::accept4(fd,nullptr,nullptr,SOCK_CLOEXEC); if(c<0&&errno==EINTR) continue; if(c<0) throw std::runtime_error(std::string("accept failed: ")+std::strerror(errno)); return c; } }
void sendFrame(int fd,const std::vector<std::uint8_t>& p) {
    const auto h=frameHeader(p.size()); writeAll(fd,h.data(),h.size()); writeAll(fd,p.data(),p.size());
}
std::vector<std::uint8_t> receiveFrame(int fd) {
    auto frame=receiveFrameWithFd(fd);
    if(frame.fd>=0) { ::close(frame.fd); throw ProtocolError("unexpected file descriptor on ordinary frame"); }
    return std::move(frame.payload);
}
void sendFrameWithFd(int socketFd,const std::vector<std::uint8_t>& payload,int fdToSend) {
    if(fdToSend<0) throw std::invalid_argument("fdToSend must be a valid file descriptor");
    const auto h=frameHeader(payload.size());
    std::vector<std::uint8_t> frame; frame.reserve(h.size()+payload.size());
    frame.insert(frame.end(),h.begin(),h.end()); frame.insert(frame.end(),payload.begin(),payload.end());
    struct iovec iov { frame.data(), frame.size() };
    alignas(struct cmsghdr) char control[CMSG_SPACE(sizeof(int))]{};
    struct msghdr msg{}; msg.msg_iov=&iov; msg.msg_iovlen=1; msg.msg_control=control; msg.msg_controllen=sizeof(control);
    struct cmsghdr* cmsg=CMSG_FIRSTHDR(&msg); cmsg->cmsg_level=SOL_SOCKET; cmsg->cmsg_type=SCM_RIGHTS; cmsg->cmsg_len=CMSG_LEN(sizeof(int));
    std::memcpy(CMSG_DATA(cmsg),&fdToSend,sizeof(fdToSend)); msg.msg_controllen=sizeof(control);
    ssize_t sent;
    do { sent=::sendmsg(socketFd,&msg,MSG_NOSIGNAL); } while(sent<0&&errno==EINTR);
    if(sent<0) throw std::runtime_error(std::string("sendmsg(SCM_RIGHTS) failed: ")+std::strerror(errno));
    if(sent==0) throw std::runtime_error("sendmsg returned zero bytes");
    if(static_cast<std::size_t>(sent)<frame.size()) writeAll(socketFd,frame.data()+sent,frame.size()-static_cast<std::size_t>(sent));
}
ReceivedFrame receiveFrameWithFd(int socketFd) {
    std::uint8_t header[4]{};
    struct iovec iov { header, sizeof(header) };
    // Allow room to detect and close unexpected extra descriptors instead of leaking them.
    alignas(struct cmsghdr) char control[CMSG_SPACE(sizeof(int)*8)]{};
    struct msghdr msg{}; msg.msg_iov=&iov; msg.msg_iovlen=1; msg.msg_control=control; msg.msg_controllen=sizeof(control);
    ssize_t got;
    do { got=::recvmsg(socketFd,&msg,MSG_CMSG_CLOEXEC); } while(got<0&&errno==EINTR);
    if(got==0) throw std::runtime_error("peer disconnected");
    if(got<0) throw std::runtime_error(std::string("recvmsg failed: ")+std::strerror(errno));
    int receivedFd=-1; unsigned fdCount=0;
    for(struct cmsghdr* c=CMSG_FIRSTHDR(&msg);c;c=CMSG_NXTHDR(&msg,c)) {
        if(c->cmsg_level==SOL_SOCKET&&c->cmsg_type==SCM_RIGHTS) {
            const auto bytes=c->cmsg_len>=CMSG_LEN(0)?c->cmsg_len-CMSG_LEN(0):0;
            const auto count=bytes/sizeof(int); const int* fds=reinterpret_cast<const int*>(CMSG_DATA(c));
            for(std::size_t i=0;i<count;++i) { ++fdCount; if(receivedFd<0) receivedFd=fds[i]; else ::close(fds[i]); }
        }
    }
    auto failAndClose=[&](const char* why)->ReceivedFrame { if(receivedFd>=0) ::close(receivedFd); throw ProtocolError(why); };
    if((msg.msg_flags&MSG_CTRUNC)!=0) return failAndClose("truncated ancillary data");
    if(fdCount>1) return failAndClose("only one file descriptor is allowed per frame");
    if(got<4) readAll(socketFd,header+got,4-static_cast<std::size_t>(got));
    const auto n=parseLength(header); std::vector<std::uint8_t> payload(n); readAll(socketFd,payload.data(),payload.size());
    return ReceivedFrame{std::move(payload),receivedFd};
}
void closeFd(int& fd) noexcept { if(fd>=0) { ::shutdown(fd,SHUT_RDWR); ::close(fd); fd=-1; } }
}
