#include "stbipc/Services.h"

#include "stbipc/ApiIds.h"

#include <iostream>

namespace stbipc {

void registerExampleServices(IpcServer& server)
{
    server.registerApi(api::Player, api::Play, [](const Args& args) -> Args {
        const auto& url = argAs<std::string>(args, 0);
        const auto& autoplay = argAs<bool>(args, 1);
        std::cout << "[Player] play url=" << url << " autoplay=" << autoplay << '\n';
        return {std::string("accepted")};
    });

    server.registerApi(api::Player, api::Pause, [](const Args&) -> Args {
        std::cout << "[Player] pause\n";
        return {};
    });

    server.registerApi(api::Player, api::GetState, [](const Args&) -> Args {
        return {std::string("PLAYING"), std::uint32_t(1)};
    });

    server.registerApi(api::Drm, api::SendLicense, [](const Args& args) -> Args {
        const auto& xml = argAs<std::string>(args, 0);
        const auto& systemId = argAs<std::string>(args, 1);
        const auto messageType = argAs<std::uint32_t>(args, 2);
        std::cout << "[DRM] XML bytes=" << xml.size()
                  << " systemID=" << systemId
                  << " messageType=" << messageType << '\n';
        return {true, std::string("license-forwarded")};
    });

    server.registerApi(api::Tuner, api::Tune, [](const Args& args) -> Args {
        const auto channel = argAs<std::uint32_t>(args, 0);
        std::cout << "[Tuner] tune channel=" << channel << '\n';
        return {true};
    });

    server.registerApi(api::Recorder, api::StartRecording, [](const Args& args) -> Args {
        const auto& recordingId = argAs<std::string>(args, 0);
        const auto duration = argAs<std::uint32_t>(args, 1);
        std::cout << "[Recorder] start id=" << recordingId
                  << " duration=" << duration << '\n';
        return {std::string("recording-started")};
    });

    server.registerApi(api::Epg, api::QueryNowNext, [](const Args& args) -> Args {
        const auto serviceId = argAs<std::uint32_t>(args, 0);
        return {serviceId, std::string("News at 20:00"), std::string("Weather at 21:00")};
    });

    server.registerApi(api::Plugin, api::Notify, [](const Args& args) -> Args {
        const auto& event = argAs<std::string>(args, 0);
        std::cout << "[Plugin notification] " << event << '\n';
        return {};
    });
}

} // namespace stbipc
