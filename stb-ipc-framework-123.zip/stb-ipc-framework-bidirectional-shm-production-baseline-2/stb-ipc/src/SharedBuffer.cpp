#include "stbipc/SharedBuffer.h"
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <unistd.h>
#include <fcntl.h>
#include <cerrno>
#include <cstdint>
#include <cstring>
#include <limits>
#include <stdexcept>
#include <utility>

#ifndef MFD_CLOEXEC
#define MFD_CLOEXEC 0x0001U
#endif
namespace stbipc {
namespace {
constexpr std::size_t kMaxSharedBufferBytes = 512U * 1024U * 1024U;
int createMemfd(const std::string& name) {
#ifdef SYS_memfd_create
    return static_cast<int>(::syscall(SYS_memfd_create, name.c_str(), MFD_CLOEXEC));
#else
    (void)name; errno=ENOSYS; return -1;
#endif
}
}
SharedBuffer::SharedBuffer(int fd,std::size_t size) noexcept : fd_(fd),size_(size) {}
SharedBuffer::~SharedBuffer(){ reset(); }
SharedBuffer::SharedBuffer(SharedBuffer&& other) noexcept : fd_(other.fd_),size_(other.size_) { other.fd_=-1; other.size_=0; }
SharedBuffer& SharedBuffer::operator=(SharedBuffer&& other) noexcept {
    if(this!=&other){ reset(); fd_=other.fd_; size_=other.size_; other.fd_=-1; other.size_=0; } return *this;
}
SharedBuffer SharedBuffer::create(std::size_t size,const std::string& name) {
    if(size==0||size>kMaxSharedBufferBytes||size>static_cast<std::size_t>(std::numeric_limits<off_t>::max())) throw std::invalid_argument("shared buffer size is outside allowed range");
    int fd=createMemfd(name);
    if(fd<0) throw std::runtime_error(std::string("memfd_create failed: ")+std::strerror(errno));
    if(::ftruncate(fd,static_cast<off_t>(size))<0){const int e=errno;::close(fd);throw std::runtime_error(std::string("ftruncate failed: ")+std::strerror(e));}
    return SharedBuffer(fd,size);
}
int SharedBuffer::release() noexcept { int out=fd_; fd_=-1; size_=0; return out; }
void SharedBuffer::reset() noexcept { if(fd_>=0)::close(fd_); fd_=-1; size_=0; }
void* mapSharedBuffer(int fd,std::size_t size,bool writable) {
    if(fd<0||size==0||size>kMaxSharedBufferBytes) throw std::invalid_argument("invalid shared buffer FD or size");
    struct stat st{};
    if(::fstat(fd,&st)<0) throw std::runtime_error(std::string("fstat shared buffer failed: ")+std::strerror(errno));
    if(st.st_size<0||static_cast<std::uint64_t>(st.st_size)<static_cast<std::uint64_t>(size)) throw std::invalid_argument("shared buffer FD is smaller than declared size");
    const int prot=PROT_READ|(writable?PROT_WRITE:0);
    void* p=::mmap(nullptr,size,prot,MAP_SHARED,fd,0);
    if(p==MAP_FAILED) throw std::runtime_error(std::string("mmap shared buffer failed: ")+std::strerror(errno));
    return p;
}
}
