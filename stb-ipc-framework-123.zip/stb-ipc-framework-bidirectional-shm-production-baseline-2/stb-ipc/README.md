# STB IPC Framework — generic typed protocol prototype

C++17 Linux prototype for a WebKitWPE WebProcess ↔ Middleware process boundary using a Unix domain stream socket. The code is intended as a compilable starting point for the protocol/serialization layer; native STB APIs and WebKitWPE integration must be supplied by the product.

## C/C++ integration

The core IPC client is implemented in C++17. C modules can use the C ABI in `include/stbipc/c_api.h`; it wraps connect/disconnect, synchronous request/reply, one-way messages, event callbacks, typed arguments, and response memory management. See `API_README.md` for the complete C API reference and `examples/c_client_example.c` for a working C caller. The build also compiles `tests/c_api_header_test.c` as C to validate header compatibility.

## Build

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j
ctest --test-dir build --output-on-failure
```

## Run the demo

Terminal 1:

```sh
./build/stb_ipc_server /tmp/stb-ipc-demo.sock
```

Terminal 2:

```sh
./build/stb_ipc_client /tmp/stb-ipc-demo.sock
```

The client demonstrates a multi-parameter Player API, a DRM API (`xml`, `systemID`, `messageType`), EPG query response, one-way notification, and receiving asynchronous EPG events. The server currently accepts one client at a time.

## Source layout

- `include/stbipc/Value.h` — typed value variant and checked argument extraction.
- `include/stbipc/Protocol.h`, `src/Protocol.cpp` — protocol schema and serialization.
- `include/stbipc/UnixSocket.h`, `src/UnixSocket.cpp` — length-prefixed Unix socket framing.
- `include/stbipc/IpcClient.h`, `src/IpcClient.cpp` — request correlation, pending requests, reply timeout, background reader, bounded socket send timeout, and safe client disconnect/shutdown.
- `include/stbipc/IpcServer.h`, `src/IpcServer.cpp` — class/API dispatch and response status mapping.
- `include/stbipc/ApiIds.h` — example class/API identifiers.
- `src/Services.cpp` — mock Player, DRM, Tuner, Recorder, EPG and Plugin handlers.
- `examples/` — runnable demo client and server.
- `tests/protocol_test.cpp` — round-trip test for all supported value types.
- `include/stbipc/SharedBuffer.h`, `src/SharedBuffer.cpp` — Linux `memfd` shared buffer creation and safe mapping checks.
- `tests/fd_transfer_test.cpp` — `SCM_RIGHTS` transfer and cross-endpoint shared-buffer mapping test.
- `API_README.md` — detailed API reference, parameters, ownership, examples and production checklist.

## Wire format

Each socket frame starts with a 4-byte little-endian payload length. The payload starts with:

| Field | Size |
|---|---:|
| Magic (`STBI`) | 4 bytes |
| Protocol version | 2 bytes |
| Message type | 1 byte |
| Reserved | 1 byte |
| Request ID | 8 bytes |
| Class ID | 4 bytes |
| API ID | 4 bytes |
| Status | 2 bytes |
| Argument count | 2 bytes |

Each argument has a 4-byte type header followed by its value. Strings and byte arrays carry a 4-byte length. All integer fields are little-endian. Supported types: signed/unsigned 32-bit and 64-bit integers, Boolean, IEEE-754 double, UTF-8/string bytes, and byte arrays.

Message types: `Request`, `Response`, `Event`, `OneWay`. Requests and responses use the same nonzero request ID. Events and one-way commands use request ID zero. Responses echo the class/API IDs. API handlers are registered by `(classId, apiId)`.

## Important implementation notes

This is a prototype, not a drop-in production certification. Before deploying on an STB:

1. Put the socket in a service-owned directory (for example `/run/stb-ipc/`) with strict directory and socket permissions; authenticate peers using `SO_PEERCRED` and validate expected UID/GID.
2. Add handshake/capability negotiation, API schema validation, explicit compatibility policy, request cancellation, per-API deadlines, rate limits, and structured logging.
3. Replace demo handlers with real native middleware adapters. Do not pass raw pointers or C++ object layouts across processes.
4. For large video/media buffers, pass file descriptors with `SCM_RIGHTS` and define ownership, lifetime, size, access mode, and synchronization. The framework now includes single-FD `SCM_RIGHTS` transfer (`sendFrameWithFd` / `receiveFrameWithFd`) and a Linux `memfd` shared-buffer helper. See `API_README.md` for the API contracts, examples, ownership rules and DMA-BUF limitations. Multi-plane DMA-BUF requiring multiple plane FDs is not implemented yet.
5. Use a bounded worker pool and a multi-client model if required. The demo server currently handles one client synchronously; an expensive native API can block subsequent requests on that connection.
6. Keep event callbacks short. Queue work from callbacks onto a separate application thread; do not issue blocking IPC calls directly from the reader-thread callback.
7. The demo uses a length-prefixed stream protocol. Never assume a single `send()` corresponds to a single `recv()`; the socket helpers correctly read/write exact lengths.
8. Validate exact argument count and type for each registered API. `argAs<T>` validates a requested position, but each handler must also reject unexpected extra parameters if strict schemas are required.
9. Add integration tests for disconnects, malformed frames, timeouts, concurrent calls, server restart, permission failures, and incompatible protocol versions. The current `client_stop_test` covers reader wake-up and pending-call failure during client disconnect.

## Current API examples

- Player `Play`: `(string url, bool autoplay) -> (string result)`
- Player `Pause`: `() -> ()`
- Player `GetState`: `() -> (string state, uint32 stateCode)`
- DRM `SendLicense`: `(string xml, string systemID, uint32 messageType) -> (bool accepted, string result)`
- Tuner `Tune`: `(uint32 channel) -> (bool accepted)`
- Recorder `StartRecording`: `(string recordingId, uint32 durationSeconds) -> (string result)`
- EPG `QueryNowNext`: `(uint32 serviceId) -> (uint32 serviceId, string now, string next)`
- Plugin `Notify`: `(string eventName) -> one-way`
- EPG `EpgEvent`: server-to-client asynchronous event ID reserved in `ApiIds.h`

## Error behavior

Server-side `invalid_argument`, missing API (`out_of_range`), and other exceptions map to `InvalidArgument`, `NotFound`, and `InternalError`. Client-side `call()` throws on timeout, disconnect, or non-OK status. For a product integration, expose a stable error object to the plugin rather than leaking exception text across the JavaScript boundary.

## WebProcess constructor: do not call the server's `main()`

`examples/server_main.cpp` is the **Middleware/server process entry point**. Do not call its `main()` (sometimes informally called `libmain`) from a WebProcess or plugin constructor. `IpcServer::run()` is intentionally a blocking accept/dispatch loop; calling it on the WebProcess thread prevents construction and event-loop work from continuing. It also puts the server in the wrong process boundary.

Correct process layout:

```text
Middleware process                         WebKit WebProcess
------------------                         -----------------
stb_ipc_server                              WebProcess/plugin constructor
  IpcServer::run() [blocking]                 creates IPC bridge
  accepts client requests                     starts worker thread
  dispatches to native player/DRM             worker connects as IpcClient
  sends replies/events          <---------->   queues API calls; handles replies
```

Start `stb_ipc_server` under the Middleware/service lifecycle (init/systemd/product launcher). In the WebProcess, use `IpcClient` or the C wrapper as a client. `examples/webprocess_constructor_safe.cpp` demonstrates a bridge whose constructor starts a worker thread and returns; API calls are queued, and synchronous request/reply calls run on that worker rather than blocking the WebProcess/main thread. Async event callbacks run on the IPC reader thread: production code must marshal them to the WebKit run loop before accessing WebKit/plugin objects.

Build and run:

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j4

# Terminal 1: Middleware owns and runs the blocking server loop
./build/stb_ipc_server /tmp/stb-ipc-demo.sock

# Terminal 2: standalone example of a non-blocking WebProcess-side constructor
./build/stb_ipc_webprocess_bridge /tmp/stb-ipc-demo.sock
```

If an architecture genuinely needs to host a server in the same process, it must be explicitly started on a managed background thread and stopped/joined during shutdown. That is not the recommended WebProcess ↔ Middleware architecture; a server running in WebProcess cannot replace the separate Middleware server.

## Existing Middleware main() integration and clean shutdown

If your Middleware already owns `main()`, do not add another entry point and do not call the server's `main()` from WebKit. Link `stbipc_middleware_service` and call `middleware_ipc_start(socketPath)` after the Middleware dependencies are initialized. The helper starts `IpcServer::run()` on a dedicated thread and returns only after the socket is ready. Call `middleware_ipc_stop()` before shutting down resources used by IPC handlers. `IpcServer::stop()` wakes blocked `accept()`/`recv()` operations, and `run()` owns final descriptor cleanup. See `API_README.md` for the full lifecycle contract.

## Bidirectional APIs and shared-memory payloads

Both processes can register APIs. Middleware uses `IpcServer::registerApi()` for calls from WebProcess and `IpcServer::callClient()` to invoke an API registered using `IpcClient::registerApi()` in WebProcess. See `API_README.md` for a complete code example, timeout behavior, handler thread rules, and deadlock guidance. `bidirectional_api_test` exercises request/reply in both directions.

For large payloads, `stb_ipc_shared_buffer_example` demonstrates a Linux `memfd` shared buffer transferred using `SCM_RIGHTS`. It uses a dedicated socketpair. In the product, use a dedicated Unix data socket unless both RPC receive loops are deliberately extended to accept FD-bearing frames; ordinary RPC frames currently reject unexpected file descriptors. DMA-BUF requires platform-specific import and synchronization handling. Review the production deployment checklist in `API_README.md` before using this baseline on an STB.

For C integrations, `stbipc_client_register_api()` lets WebProcess expose APIs to Middleware, while `middleware_ipc_register_api()` and `middleware_ipc_call_client()` let an existing C Middleware layer expose APIs to WebProcess and call WebProcess APIs. See the C ABI section in `API_README.md` for callback ownership rules and a `main()` integration example.
