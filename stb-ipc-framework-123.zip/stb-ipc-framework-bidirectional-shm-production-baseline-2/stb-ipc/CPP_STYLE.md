# C++ formatting

The C++ source uses the checked-in `.clang-format` style (LLVM base, four-space indentation,
100-column target, no tabs). The protocol encoder/decoder, IPC client/server, service examples,
and WebProcess bridge have been aligned to this style for easier review and maintenance.

To apply the same style to all C/C++ source files on a development machine with `clang-format`:

```bash
find include src examples tests -type f \\
  \( -name '*.h' -o -name '*.hpp' -o -name '*.cpp' -o -name '*.c' \) \\
  -print0 | xargs -0 clang-format -i
```

The C ABI implementation remains a C++ translation unit and the public `c_api.h` remains
valid C. Formatting does not change the IPC wire format or API identifiers.
