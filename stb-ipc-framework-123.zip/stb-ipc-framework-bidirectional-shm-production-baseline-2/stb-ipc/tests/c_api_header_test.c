#include "stbipc/c_api.h"
#include <string.h>

int main(void)
{
    /* This file is compiled as C to validate that the public header is C-safe. */
    stbipc_client *client = stbipc_client_create("/tmp/stb-ipc-c-header-test.sock");
    if (!client) return 1;
    if (stbipc_client_is_connected(client) != 0) return 2;
    if (strcmp(stbipc_last_error(), "No error") != 0) return 3;
    stbipc_client_destroy(client);
    return 0;
}
