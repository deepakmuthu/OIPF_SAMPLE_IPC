#include "stbipc/SharedBuffer.h"
#include "stbipc/UnixSocket.h"
#include <sys/socket.h>
#include <sys/mman.h>
#include <unistd.h>
#include <cassert>
#include <cstring>
#include <iostream>
#include <vector>

int main() {
    using namespace stbipc;
    int pair[2]{};
    if(::socketpair(AF_UNIX,SOCK_STREAM|SOCK_CLOEXEC,0,pair)<0) return 2;
    try {
        constexpr std::size_t kSize=4096;
        auto buffer=SharedBuffer::create(kSize,"stb-ipc-test");
        void* writer=mapSharedBuffer(buffer.fd(),kSize,true);
        std::memcpy(writer,"shared video frame payload",27);
        auto payload=std::vector<std::uint8_t>{0x53,0x54,0x42,0x01};
        sendFrameWithFd(pair[0],payload,buffer.fd());
        auto received=receiveFrameWithFd(pair[1]);
        assert(received.payload==payload);
        assert(received.fd>=0);
        void* reader=mapSharedBuffer(received.fd,kSize,false);
        assert(std::memcmp(reader,"shared video frame payload",27)==0);
        ::munmap(reader,kSize); ::munmap(writer,kSize); ::close(received.fd);
        ::close(pair[0]); ::close(pair[1]);
        std::cout << "SCM_RIGHTS shared-buffer transfer passed\n";
    } catch (...) { ::close(pair[0]); ::close(pair[1]); throw; }
}
