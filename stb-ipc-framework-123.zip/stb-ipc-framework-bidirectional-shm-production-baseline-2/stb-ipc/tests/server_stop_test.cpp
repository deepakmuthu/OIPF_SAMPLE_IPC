#include "stbipc/IpcServer.h"
#include "stbipc/UnixSocket.h"

#include <chrono>
#include <cstdio>
#include <stdexcept>
#include <string>
#include <thread>
#include <sys/stat.h>
#include <unistd.h>

int main()
{
    const std::string socketPath =
        "/tmp/stb-ipc-stop-test-" + std::to_string(static_cast<long long>(::getpid())) + ".sock";
    stbipc::IpcServer server(socketPath);
    std::thread serverThread([&server]() {
        try {
            server.run();
        } catch (...) {
            // Test reports startup/readiness failures from the main thread.
        }
    });

    if (!server.waitUntilReady(std::chrono::seconds(2))) {
        server.stop();
        if (serverThread.joinable()) {
            serverThread.join();
        }
        std::fprintf(stderr, "server failed to become ready\n");
        return 1;
    }

    // Exercise shutdown while the server may be blocked in accept() or recv().
    int clientFd = stbipc::connectUnix(socketPath);
    std::this_thread::sleep_for(std::chrono::milliseconds(50));

    const auto start = std::chrono::steady_clock::now();
    server.stop();
    serverThread.join();
    stbipc::closeFd(clientFd);
    const auto elapsed = std::chrono::steady_clock::now() - start;

    struct stat st {};
    if (::lstat(socketPath.c_str(), &st) == 0) {
        std::fprintf(stderr, "socket path was not removed after stop\n");
        return 1;
    }
    if (elapsed > std::chrono::seconds(2)) {
        std::fprintf(stderr, "stop() did not wake run() promptly\n");
        return 1;
    }

    std::puts("server stop test passed");
    return 0;
}
