#include "stbipc/IpcClient.h"
#include "stbipc/IpcServer.h"

#include <atomic>
#include <chrono>
#include <cstdio>
#include <string>
#include <thread>
#include <unistd.h>

using namespace std::chrono_literals;

int main()
{
    const std::string path = "/tmp/stb-ipc-client-stop-" +
        std::to_string(static_cast<long long>(::getpid())) + ".sock";
    stbipc::IpcServer server(path);
    server.registerApi(1, 1, [](const stbipc::Args&) {
        // Keep the request outstanding long enough to test client shutdown.
        std::this_thread::sleep_for(600ms);
        return stbipc::Args{};
    });

    std::thread serverThread([&server]() {
        try { server.run(); } catch (...) {}
    });
    if (!server.waitUntilReady(2s)) {
        server.stop();
        serverThread.join();
        std::fprintf(stderr, "server failed to become ready\n");
        return 1;
    }

    stbipc::IpcClient client(path);
    try {
        client.connect();
    } catch (const std::exception& e) {
        server.stop();
        serverThread.join();
        std::fprintf(stderr, "client connect failed: %s\n", e.what());
        return 1;
    }

    std::atomic<bool> callFinished{false};
    std::thread callThread([&]() {
        try {
            (void)client.call(1, 1, {}, 5s);
        } catch (...) {
            // Disconnect is expected to fail this pending request.
        }
        callFinished = true;
    });

    std::this_thread::sleep_for(100ms);
    const auto start = std::chrono::steady_clock::now();
    client.disconnect();
    callThread.join();
    const auto elapsed = std::chrono::steady_clock::now() - start;

    server.stop();
    serverThread.join();

    if (!callFinished || elapsed > 1500ms) {
        std::fprintf(stderr, "client disconnect did not wake pending call promptly\n");
        return 1;
    }

    std::puts("client stop test passed");
    return 0;
}
