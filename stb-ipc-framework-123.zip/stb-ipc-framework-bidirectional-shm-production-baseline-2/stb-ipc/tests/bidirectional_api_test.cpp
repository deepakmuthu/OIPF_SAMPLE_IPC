#include "stbipc/IpcClient.h"
#include "stbipc/IpcServer.h"

#include <cassert>
#include <chrono>
#include <cstdio>
#include <string>
#include <thread>
#include <unistd.h>

int main()
{
    using namespace stbipc;
    const std::string socketPath = "/tmp/stb-ipc-bidir-" + std::to_string(::getpid()) + ".sock";
    IpcServer server(socketPath);
    server.registerApi(10, 1, [](const Args& args) -> Args {
        return {argAs<std::uint32_t>(args, 0) + 1U};
    });

    std::thread serverThread([&server] { server.run(); });
    if (!server.waitUntilReady(std::chrono::seconds(2))) {
        server.stop();
        serverThread.join();
        return 2;
    }

    IpcClient client(socketPath);
    client.registerApi(20, 2, [](const Args& args) -> Args {
        const auto& message = argAs<std::string>(args, 0);
        return {std::string("client-received:") + message};
    });
    client.connect();

    try {
        const auto clientToServer = client.call(10, 1, {std::uint32_t(40)});
        assert(argAs<std::uint32_t>(clientToServer.args, 0) == 41U);

        const auto serverToClient = server.callClient(20, 2, {std::string("hello")},
                                                       std::chrono::seconds(2));
        assert(argAs<std::string>(serverToClient.args, 0) == "client-received:hello");
    } catch (...) {
        client.disconnect();
        server.stop();
        serverThread.join();
        throw;
    }

    client.disconnect();
    server.stop();
    serverThread.join();
    std::puts("bidirectional API registration and request/reply passed");
    return 0;
}
