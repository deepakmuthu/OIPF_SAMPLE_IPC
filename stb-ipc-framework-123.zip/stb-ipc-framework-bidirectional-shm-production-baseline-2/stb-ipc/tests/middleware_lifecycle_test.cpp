#include "stbipc/middleware_ipc.h"

#include <cstdio>
#include <string>
#include <sys/stat.h>
#include <unistd.h>

int main()
{
    const std::string socketPath =
        "/tmp/stb-ipc-lifecycle-test-" +
        std::to_string(static_cast<long long>(::getpid())) + ".sock";

    if (middleware_ipc_start(socketPath.c_str()) != 0) {
        std::fprintf(stderr, "middleware_ipc_start() failed\n");
        return 1;
    }

    struct stat st {};
    if (::lstat(socketPath.c_str(), &st) != 0) {
        std::fprintf(stderr, "IPC socket was not created\n");
        middleware_ipc_stop();
        return 1;
    }

    middleware_ipc_stop();
    middleware_ipc_stop(); // Stop is intentionally idempotent.

    if (::lstat(socketPath.c_str(), &st) == 0) {
        std::fprintf(stderr, "IPC socket was not removed after stop\n");
        return 1;
    }

    std::puts("middleware lifecycle test passed");
    return 0;
}
