#include "stbipc/IpcClient.h"
#include "stbipc/ApiIds.h"
#include <iostream>
#include <thread>
int main(int argc,char** argv){const std::string path=argc>1?argv[1]:"/tmp/stb-ipc-demo.sock";try{stbipc::IpcClient c(path);c.setEventHandler([](const stbipc::Message& m){std::cout<<"[Async event] class="<<m.classId<<" api="<<m.apiId<<" args="<<m.args.size()<<"\n";});c.connect();
 auto play=c.call(stbipc::api::Player,stbipc::api::Play,{std::string("https://example.test/video.mpd"),true});std::cout<<"play result: "<<stbipc::argAs<std::string>(play.args,0)<<"\n";
 auto drm=c.call(stbipc::api::Drm,stbipc::api::SendLicense,{std::string("<license>abc</license>"),std::string("com.example.drm"),std::uint32_t(2)});std::cout<<"DRM result: "<<stbipc::argAs<bool>(drm.args,0)<<", "<<stbipc::argAs<std::string>(drm.args,1)<<"\n";
 auto epg=c.call(stbipc::api::Epg,stbipc::api::QueryNowNext,{std::uint32_t(1001)});std::cout<<"EPG service="<<stbipc::argAs<std::uint32_t>(epg.args,0)<<" now="<<stbipc::argAs<std::string>(epg.args,1)<<" next="<<stbipc::argAs<std::string>(epg.args,2)<<"\n";
 c.sendOneWay(stbipc::api::Plugin,stbipc::api::Notify,{std::string("BUFFERING_STARTED")});std::this_thread::sleep_for(std::chrono::seconds(7));c.disconnect();
 }catch(const std::exception& e){std::cerr<<"client error: "<<e.what()<<"\n";return 1;}return 0;}
