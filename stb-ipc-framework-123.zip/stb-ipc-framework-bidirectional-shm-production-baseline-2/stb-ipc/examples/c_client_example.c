#include "stbipc/c_api.h"
#include <stdio.h>

int main(int argc, char **argv)
{
    const char *socket_path = argc > 1 ? argv[1] : "/tmp/stb-ipc-demo.sock";
    stbipc_client *client = stbipc_client_create(socket_path);
    if (!client) {
        fprintf(stderr, "create failed: %s\n", stbipc_last_error());
        return 1;
    }
    if (stbipc_client_connect(client) != 0) {
        fprintf(stderr, "connect failed: %s\n", stbipc_last_error());
        stbipc_client_destroy(client);
        return 1;
    }

    /* Player.Play (class ID 1, API ID 1): string URL + bool autoplay. */
    stbipc_value args[2] = {0};
    args[0].type = STBIPC_VALUE_STRING;
    args[0].as.string = "https://example.com/video.mpd";
    args[1].type = STBIPC_VALUE_BOOL;
    args[1].as.boolean = 1;

    stbipc_value *response = NULL;
    size_t response_count = 0;
    if (stbipc_client_call(client, 1, 1, args, 2, 3000,
                           &response, &response_count) != 0) {
        fprintf(stderr, "Player.Play failed: %s\n", stbipc_last_error());
        stbipc_client_destroy(client);
        return 1;
    }

    if (response_count > 0 && response[0].type == STBIPC_VALUE_STRING)
        printf("Player.Play result: %s\n", response[0].as.string);
    else
        printf("Player.Play completed; response arguments: %zu\n", response_count);

    stbipc_values_free(response, response_count);
    stbipc_client_disconnect(client);
    stbipc_client_destroy(client);
    return 0;
}
