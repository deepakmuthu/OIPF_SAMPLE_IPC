#include "stbipc/Services.h"
#include "stbipc/ApiIds.h"
#include <iostream>
#include <thread>
int main(int argc,char** argv){const std::string path=argc>1?argv[1]:"/tmp/stb-ipc-demo.sock";try{stbipc::IpcServer server(path);stbipc::registerExampleServices(server);std::cout<<"STB IPC server listening at "<<path<<"\n";std::thread events([&server]{for(std::uint32_t i=1;i<=5;++i){std::this_thread::sleep_for(std::chrono::seconds(2));try{server.emitEvent(stbipc::api::Epg,stbipc::api::EpgEvent,{std::string("EPG_PROGRAM_CHANGED"),i});}catch(...){} }});server.run();events.join();}catch(const std::exception& e){std::cerr<<"server error: "<<e.what()<<"\n";return 1;}return 0;}
