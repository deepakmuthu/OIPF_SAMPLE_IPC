// Demonstrates transferring a large buffer by FD, not copying its bytes through
// the IPC message. For production, use a dedicated SCM_RIGHTS data socket (or
// integrate ancillary-FD handling into the framed IPC reader as a coordinated
// protocol change). The socketpair here keeps the example deterministic.
#include "stbipc/SharedBuffer.h"
#include "stbipc/UnixSocket.h"

#include <sys/mman.h>
#include <sys/socket.h>
#include <unistd.h>

#include <cstdint>
#include <cstring>
#include <iostream>
#include <stdexcept>
#include <vector>

int main()
{
    using namespace stbipc;
    int sockets[2]{-1, -1};
    if (::socketpair(AF_UNIX, SOCK_STREAM | SOCK_CLOEXEC, 0, sockets) < 0) {
        throw std::runtime_error("socketpair failed");
    }

    try {
        constexpr std::size_t kFrameBytes = 8U * 1024U * 1024U;
        auto shared = SharedBuffer::create(kFrameBytes, "stb-video-frame");
        void* writerMap = mapSharedBuffer(shared.fd(), shared.size(), true);
        std::memset(writerMap, 0, shared.size());
        const char sample[] = "STB shared video frame / large payload";
        std::memcpy(writerMap, sample, sizeof(sample));

        // Only metadata travels in the framed message; SCM_RIGHTS transfers a
        // duplicate FD referring to the same kernel-backed shared-memory object.
        const std::vector<std::uint8_t> metadata{0x53, 0x48, 0x4D, 0x01};
        sendFrameWithFd(sockets[0], metadata, shared.fd());
        auto received = receiveFrameWithFd(sockets[1]);
        if (received.payload != metadata || received.fd < 0) {
            throw std::runtime_error("invalid shared-buffer transfer metadata/FD");
        }

        void* readerMap = mapSharedBuffer(received.fd, kFrameBytes, false);
        if (std::memcmp(readerMap, sample, sizeof(sample)) != 0) {
            throw std::runtime_error("shared buffer content verification failed");
        }
        std::cout << "Transferred and verified " << kFrameBytes
                  << " bytes using SCM_RIGHTS + mmap (payload not copied over socket).\n";

        if (::munmap(readerMap, kFrameBytes) < 0) {
            throw std::runtime_error("munmap receiver failed");
        }
        if (::munmap(writerMap, kFrameBytes) < 0) {
            throw std::runtime_error("munmap sender failed");
        }
        closeFd(received.fd);
        closeFd(sockets[0]);
        closeFd(sockets[1]);
    } catch (...) {
        closeFd(sockets[0]);
        closeFd(sockets[1]);
        throw;
    }
    return 0;
}
