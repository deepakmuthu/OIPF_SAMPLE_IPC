/*
 * Demonstrates the correct WebProcess-side lifecycle.
 *
 * Do NOT call server_main.cpp's main() from a WebProcess constructor. The
 * Middleware owns the server; WebProcess is an IPC client. This bridge starts
 * its worker thread immediately and performs connection/calls there, so the
 * WebKit/WebProcess constructor and main thread do not wait for IPC replies.
 *
 * This is a standalone integration example, not a WebKit-specific hook. In a
 * real port, marshal events onto the WebKit run loop before touching WebKit
 * objects. Never call WebKit APIs directly from the IPC reader callback.
 */
#include "stbipc/ApiIds.h"
#include "stbipc/IpcClient.h"

#include <condition_variable>
#include <iostream>
#include <mutex>
#include <queue>
#include <string>
#include <thread>
#include <utility>
#include <functional>

class WebProcessIpcBridge {
public:
    explicit WebProcessIpcBridge(std::string socketPath)
        : socketPath_(std::move(socketPath))
        , worker_(&WebProcessIpcBridge::workerLoop, this)
    {
    }

    ~WebProcessIpcBridge() {
        {
            std::lock_guard<std::mutex> lock(mutex_);
            stopping_ = true;
        }
        cv_.notify_one();
        if (worker_.joinable()) {
            worker_.join();
        }
    }

    WebProcessIpcBridge(const WebProcessIpcBridge&) = delete;
    WebProcessIpcBridge& operator=(const WebProcessIpcBridge&) = delete;

    // Non-blocking enqueue: safe to call from a WebProcess/application thread.
    void postPlay(std::string url, bool autoplay) {
        enqueue([url = std::move(url), autoplay](stbipc::IpcClient& client) {
            try {
                const auto response = client.call(
                    stbipc::api::Player, stbipc::api::Play,
                    {url, autoplay}, std::chrono::milliseconds(3000));
                if (!response.args.empty()) {
                    std::cout << "[WebProcess] Play result: "
                              << std::get<std::string>(response.args[0]) << '\n';
                }
            } catch (const std::exception& e) {
                std::cerr << "[WebProcess] Play IPC failed: " << e.what() << '\n';
            }
        });
    }

    void postDrmLicense(std::string xml, std::string systemId, std::uint32_t messageType) {
        enqueue([xml = std::move(xml), systemId = std::move(systemId), messageType](
                    stbipc::IpcClient& client) {
            try {
                const auto response = client.call(
                    stbipc::api::Drm, stbipc::api::SendLicense,
                    {xml, systemId, messageType}, std::chrono::milliseconds(5000));
                std::cout << "[WebProcess] DRM response received ("
                          << response.args.size() << " fields)\n";
            } catch (const std::exception& e) {
                std::cerr << "[WebProcess] DRM IPC failed: " << e.what() << '\n';
            }
        });
    }

private:
    using Job = std::function<void(stbipc::IpcClient&)>;

    void enqueue(Job job) {
        {
            std::lock_guard<std::mutex> lock(mutex_);
            if (stopping_) return;
            jobs_.push(std::move(job));
        }
        cv_.notify_one();
    }

    void workerLoop() {
        try {
            // Socket connect and the reader-thread startup happen off the
            // WebProcess constructor/main thread.
            stbipc::IpcClient client(socketPath_);
            client.setEventHandler([](const stbipc::Message& event) {
                // Production: post/copy this event to the WebKit run loop.
                // Do not access WebKit/plugin objects on this reader thread.
                std::cout << "[WebProcess] async event class=" << event.classId
                          << " api=" << event.apiId << '\n';
            });
            client.connect();
            std::cout << "[WebProcess] IPC client connected to Middleware\n";

            for (;;) {
                Job job;
                {
                    std::unique_lock<std::mutex> lock(mutex_);
                    cv_.wait(lock, [this] { return stopping_ || !jobs_.empty(); });
                    if (stopping_ && jobs_.empty()) break;
                    job = std::move(jobs_.front());
                    jobs_.pop();
                }
                job(client); // A synchronous IPC call blocks only this worker.
            }
            client.disconnect();
        } catch (const std::exception& e) {
            std::cerr << "[WebProcess] IPC worker could not connect/run: "
                      << e.what() << '\n';
        }
    }

    std::string socketPath_;
    std::mutex mutex_;
    std::condition_variable cv_;
    std::queue<Job> jobs_;
    bool stopping_{false};
    std::thread worker_;
};

// Demo only. A real WebProcess would own the bridge as a member of its
// plugin/process integration object and call postPlay/postDrmLicense from API
// dispatch points. The Middleware server must already be running separately.
int main(int argc, char** argv) {
    const std::string socketPath = argc > 1 ? argv[1] : "/tmp/stb-ipc-demo.sock";
    {
        WebProcessIpcBridge webProcessBridge(socketPath); // constructor returns promptly
        webProcessBridge.postPlay("https://example.invalid/live.mpd", true);
        webProcessBridge.postDrmLicense("<license/>", "example-system", 1);
        std::this_thread::sleep_for(std::chrono::milliseconds(200));
        // Bridge destructor requests shutdown and joins its worker.
        // In production, lifetime is the plugin/WebProcess object's lifetime.
    }
    return 0;
}
