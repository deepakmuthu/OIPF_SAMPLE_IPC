#ifndef STBIPC_MIDDLEWARE_IPC_H
#define STBIPC_MIDDLEWARE_IPC_H

#include "stbipc/c_api.h"

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Starts the IPC server on a dedicated thread and waits briefly for the
 * listening socket to become ready. Intended to be called by the existing
 * Middleware main(), not by the WebKit WebProcess.
 *
 * Returns 0 on success, -1 on invalid input/startup failure.
 */
int middleware_ipc_start(const char *socket_path);

/* Requests shutdown, wakes blocking accept/recv, joins the server thread,
 * and releases server resources. Safe to call repeatedly. */
void middleware_ipc_stop(void);

/* Register/replace a Middleware API callable by the WebProcess client. The C
 * callback runs on an IPC worker thread. Input event args are borrowed for the
 * callback; output values must be malloc-owned and are freed by the library.
 * Returns 0 on success, -1 on invalid input or if the server is not running. */
int middleware_ipc_register_api(uint32_t class_id, uint32_t api_id,
                                stbipc_api_callback callback, void *user_data);

/* Call an API registered by stbipc_client_register_api() in WebProcess. This
 * is synchronous and must be called from a Middleware worker, not the IPC
 * receive loop. timeout_ms <= 0 selects 3000 ms. Free returned values with
 * stbipc_values_free(). Returns 0 on success, -1 on error. */
int middleware_ipc_call_client(uint32_t class_id, uint32_t api_id,
                               const stbipc_value *args, size_t arg_count,
                               int timeout_ms,
                               stbipc_value **response_args,
                               size_t *response_count);

#ifdef __cplusplus
}
#endif

#endif /* STBIPC_MIDDLEWARE_IPC_H */
