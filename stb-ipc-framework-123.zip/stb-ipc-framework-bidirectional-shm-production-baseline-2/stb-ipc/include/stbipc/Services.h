#pragma once
#include "stbipc/IpcServer.h"
namespace stbipc { void registerExampleServices(IpcServer& server); }
