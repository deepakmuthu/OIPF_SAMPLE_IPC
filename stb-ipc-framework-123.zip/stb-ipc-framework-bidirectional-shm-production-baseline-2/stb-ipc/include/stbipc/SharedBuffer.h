#pragma once
#include <cstddef>
#include <string>

namespace stbipc {
// Linux memfd-backed shared memory. The returned FD may be transferred with SCM_RIGHTS.
// The receiver must obtain the agreed size from the IPC message and validate it before mmap.
class SharedBuffer {
public:
    SharedBuffer() noexcept = default;
    SharedBuffer(int fd, std::size_t size) noexcept;
    ~SharedBuffer();
    SharedBuffer(const SharedBuffer&) = delete;
    SharedBuffer& operator=(const SharedBuffer&) = delete;
    SharedBuffer(SharedBuffer&& other) noexcept;
    SharedBuffer& operator=(SharedBuffer&& other) noexcept;

    static SharedBuffer create(std::size_t size, const std::string& name="stb-ipc-buffer");
    int fd() const noexcept { return fd_; }
    std::size_t size() const noexcept { return size_; }
    int release() noexcept;
    void reset() noexcept;
private:
    int fd_{-1};
    std::size_t size_{0};
};

// Maps an already-received FD. Caller must munmap() the returned address.
// Checks that the FD refers to an object at least `size` bytes long.
void* mapSharedBuffer(int fd, std::size_t size, bool writable);
}
