#pragma once
#include <cstdint>
#include <string>
#include <vector>

namespace stbipc {
struct ReceivedFrame {
    std::vector<std::uint8_t> payload;
    // Ownership transfers to the caller. Close with closeFd() or ::close().
    // -1 means no descriptor accompanied this frame.
    int fd{-1};
};

int connectUnix(const std::string& path);
int listenUnix(const std::string& path, int backlog=8);
int acceptUnix(int listenFd);
void sendFrame(int fd, const std::vector<std::uint8_t>& payload);
std::vector<std::uint8_t> receiveFrame(int fd);
// Sends exactly one descriptor using SCM_RIGHTS with this frame.
void sendFrameWithFd(int socketFd, const std::vector<std::uint8_t>& payload, int fdToSend);
// Receives a frame and an optional descriptor. Descriptor ownership is returned to caller.
ReceivedFrame receiveFrameWithFd(int socketFd);
void closeFd(int& fd) noexcept;
}
