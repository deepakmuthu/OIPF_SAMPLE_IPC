#pragma once
#include <cstdint>
#include <string>
#include <variant>
#include <vector>
#include <stdexcept>

namespace stbipc {
using Bytes = std::vector<std::uint8_t>;
using Value = std::variant<std::int32_t, std::uint32_t, std::int64_t, std::uint64_t,
                           bool, double, std::string, Bytes>;
using Args = std::vector<Value>;

enum class ValueType : std::uint8_t { I32=1, U32=2, I64=3, U64=4, Bool=5, Double=6, String=7, Bytes=8 };
ValueType typeOf(const Value& v);
const char* typeName(ValueType t) noexcept;

template<class T> const T& argAs(const Args& args, std::size_t index) {
    if (index >= args.size()) throw std::out_of_range("missing IPC argument");
    const auto* p = std::get_if<T>(&args[index]);
    if (!p) throw std::invalid_argument("IPC argument has unexpected type");
    return *p;
}
}
