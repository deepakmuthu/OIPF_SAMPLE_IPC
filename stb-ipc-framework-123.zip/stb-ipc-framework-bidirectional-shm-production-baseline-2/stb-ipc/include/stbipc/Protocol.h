#pragma once
#include "stbipc/Value.h"
#include <cstdint>
#include <vector>
#include <stdexcept>

namespace stbipc {
constexpr std::uint32_t kMagic = 0x53544249U; // 'STBI'
constexpr std::uint16_t kProtocolVersion = 1;
constexpr std::uint32_t kMaxFrameBytes = 4U * 1024U * 1024U;
constexpr std::uint32_t kMaxStringBytes = 1024U * 1024U;
constexpr std::uint16_t kMaxArgs = 64;

enum class MessageType : std::uint8_t { Request=1, Response=2, Event=3, OneWay=4 };
enum class Status : std::uint16_t { Ok=0, InvalidArgument=1, NotFound=2, InternalError=3, Unsupported=4, Timeout=5, Disconnected=6 };
struct Message {
    MessageType type{MessageType::Request};
    std::uint64_t requestId{0};
    std::uint32_t classId{0};
    std::uint32_t apiId{0};
    Status status{Status::Ok};
    Args args;
};
class ProtocolError : public std::runtime_error { public: using std::runtime_error::runtime_error; };
std::vector<std::uint8_t> encode(const Message& message);
Message decode(const std::uint8_t* data, std::size_t size);
Message decode(const std::vector<std::uint8_t>& data);
}
