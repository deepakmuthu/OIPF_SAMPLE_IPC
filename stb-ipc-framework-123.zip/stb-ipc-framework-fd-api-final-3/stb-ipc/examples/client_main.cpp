// Example WebProcess-side IPC client.
// Do not run synchronous IPC calls on the WebKit main thread in production.
#include "stbipc/ApiIds.h"
#include "stbipc/IpcClient.h"
#include "stbipc/SharedBuffer.h"

#include <sys/mman.h>
#include <chrono>
#include <cstring>
#include <iostream>
#include <stdexcept>
#include <string>
#include <thread>

int main(int argc, char** argv)
{
    const std::string socketPath =
        argc > 1 ? argv[1] : "/tmp/stb-ipc-demo.sock";

    try {
        stbipc::IpcClient client(socketPath);

        // Events run on the IPC reader thread. Marshal WebKit-affine work to
        // the proper WebKit thread rather than accessing WebKit objects here.
        client.setEventHandler([](const stbipc::Message& event) {
            std::cout << "[Async event] class=" << event.classId
                      << " api=" << event.apiId
                      << " args=" << event.args.size() << '\n';
        });

        // Establish the Unix-domain socket and start the background reader.
        client.connect();

        // Example ordinary request/reply API call.
        auto playReply = client.call(
            stbipc::api::Player, stbipc::api::Play,
            {std::string("https://example.test/video.mpd"), true});
        std::cout << "play result: "
                  << stbipc::argAs<std::string>(playReply.args, 0) << '\n';

        // Example ordinary DRM call with a small XML payload serialized in Args.
        auto drmReply = client.call(
            stbipc::api::Drm, stbipc::api::SendLicense,
            {std::string("<license>demo</license>"),
             std::string("com.example.drm"), std::uint32_t(2)});
        std::cout << "DRM result: "
                  << stbipc::argAs<bool>(drmReply.args, 0) << ", "
                  << stbipc::argAs<std::string>(drmReply.args, 1) << '\n';

        // Large-payload example: create shared memory and write the payload.
        // The payload itself is not copied into the IPC protocol message.
        constexpr std::size_t kPayloadBytes = 8U * 1024U * 1024U;
        auto sharedBuffer =
            stbipc::SharedBuffer::create(kPayloadBytes, "stb-drm-demo");
        void* writableMapping = stbipc::mapSharedBuffer(
            sharedBuffer.fd(), sharedBuffer.size(), true);
        std::memset(writableMapping, 0x5A, sharedBuffer.size());
        if (::munmap(writableMapping, sharedBuffer.size()) != 0) {
            throw std::runtime_error("munmap() failed for client shared buffer");
        }

        // Metadata travels in the ordinary API Args. The FD is attached to the
        // same request frame through SCM_RIGHTS. The local FD remains owned by
        // SharedBuffer and stays valid until the call finishes.
        auto sharedReply = client.call(
            stbipc::api::Drm, stbipc::api::SendLicenseShared,
            {static_cast<std::uint64_t>(sharedBuffer.size()),
             std::string("com.example.drm"), std::uint32_t(2)},
            std::chrono::milliseconds(3000), sharedBuffer.fd());
        std::cout << "shared DRM result: "
                  << stbipc::argAs<bool>(sharedReply.args, 0) << ", "
                  << stbipc::argAs<std::string>(sharedReply.args, 1) << '\n';

        // Example of an API call in the opposite direction. Middleware invokes
        // a registered client API; the matching handler must be registered
        // before the server attempts this call. See the bidirectional API test.

        // Example event/one-way notification; no reply is expected.
        client.sendOneWay(stbipc::api::Plugin, stbipc::api::Notify,
                          {std::string("BUFFERING_STARTED")});

        std::this_thread::sleep_for(std::chrono::seconds(2));
        client.disconnect();
    } catch (const std::exception& error) {
        std::cerr << "client error: " << error.what() << '\n';
        return 1;
    }

    return 0;
}
