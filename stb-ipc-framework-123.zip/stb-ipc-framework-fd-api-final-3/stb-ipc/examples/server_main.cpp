// Example Middleware process entry point.
// In a real STB product, integrate this server into the existing Middleware
// lifecycle instead of creating a second main().
#include "stbipc/Services.h"
#include "stbipc/ApiIds.h"
#include "stbipc/SharedBuffer.h"
#include <sys/mman.h>
#include <unistd.h>
#include <iostream>
#include <thread>
#include <limits>

int main(int argc, char** argv)
{
    const std::string path = argc > 1 ? argv[1] : "/tmp/stb-ipc-demo.sock";
    try {
        stbipc::IpcServer server(path);
        stbipc::registerExampleServices(server);

        // This registered API receives normal metadata in Args and one optional
        // shared-memory FD through SCM_RIGHTS. The callback borrows the FD;
        // the dispatcher closes it after the callback returns.
        server.registerApiWithFd(stbipc::api::Drm, stbipc::api::SendLicenseShared,
            [](const stbipc::Args& args, int receivedFd) -> stbipc::Args {
                if (receivedFd < 0) throw std::invalid_argument("shared buffer FD is required");
                const auto size = stbipc::argAs<std::uint64_t>(args, 0);
                const auto& systemId = stbipc::argAs<std::string>(args, 1);
                const auto messageType = stbipc::argAs<std::uint32_t>(args, 2);
                constexpr std::uint64_t kMaxLicenseBytes = 16U * 1024U * 1024U;
                if (size == 0 || size > kMaxLicenseBytes || size > SIZE_MAX)
                    throw std::invalid_argument("shared license size is invalid");

                void* mapping = stbipc::mapSharedBuffer(receivedFd, static_cast<std::size_t>(size), false);
                try {
                    // Demo: inspect bytes without copying the payload. Replace this
                    // with the real Middleware/native DRM handler. Never log secrets.
                    const auto* bytes = static_cast<const unsigned char*>(mapping);
                    const unsigned int firstByte = bytes[0];
                    std::cout << "SHM DRM request: bytes=" << size
                              << " system=" << systemId
                              << " messageType=" << messageType
                              << " firstByte=" << firstByte << "\n";
                    (void)::munmap(mapping, static_cast<std::size_t>(size));
                } catch (...) {
                    (void)::munmap(mapping, static_cast<std::size_t>(size));
                    throw;
                }
                return {true, std::string("shared buffer accepted")};
            });

        std::cout << "STB IPC server listening at " << path << "\n";
        server.run(); // Blocking by design; run on Middleware/server thread.
    } catch (const std::exception& e) {
        std::cerr << "server error: " << e.what() << "\n";
        return 1;
    }
    return 0;
}
