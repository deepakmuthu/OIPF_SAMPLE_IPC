#include "stbipc/IpcClient.h"
#include "stbipc/IpcServer.h"
#include "stbipc/SharedBuffer.h"
#include <sys/mman.h>
#include <unistd.h>
#include <atomic>
#include <cassert>
#include <chrono>
#include <cstring>
#include <thread>

int main()
{
    using namespace std::chrono_literals;
    const std::string path = "/tmp/stb-ipc-registered-fd-test.sock";
    constexpr std::uint32_t cls = 77, serverApi = 1, clientApi = 2;
    constexpr std::size_t size = 4096;
    stbipc::IpcServer server(path);
    std::atomic<bool> serverSawData{false};
    server.registerApiWithFd(cls, serverApi, [&](const stbipc::Args& args, int fd) -> stbipc::Args {
        assert(fd >= 0);
        assert(stbipc::argAs<std::uint64_t>(args, 0) == size);
        void* map = stbipc::mapSharedBuffer(fd, size, false);
        const bool good = static_cast<unsigned char*>(map)[0] == 0xA5;
        (void)::munmap(map, size);
        serverSawData.store(good);
        return {good};
    });
    std::thread serverThread([&] { server.run(); });
    if (!server.waitUntilReady(2s)) { server.stop(); serverThread.join(); return 1; }

    stbipc::IpcClient client(path);
    std::atomic<bool> clientSawData{false};
    client.registerApiWithFd(cls, clientApi, [&](const stbipc::Args& args, int fd) -> stbipc::Args {
        assert(fd >= 0);
        assert(stbipc::argAs<std::uint64_t>(args, 0) == size);
        void* map = stbipc::mapSharedBuffer(fd, size, false);
        const bool good = static_cast<unsigned char*>(map)[0] == 0x5A;
        (void)::munmap(map, size);
        clientSawData.store(good);
        return {good};
    });
    client.connect();

    auto toServer = stbipc::SharedBuffer::create(size, "to-server-test");
    void* serverMap = stbipc::mapSharedBuffer(toServer.fd(), size, true);
    std::memset(serverMap, 0xA5, size);
    (void)::munmap(serverMap, size);
    auto serverReply = client.call(cls, serverApi, {static_cast<std::uint64_t>(size)}, 2s, toServer.fd());
    assert(stbipc::argAs<bool>(serverReply.args, 0));
    assert(serverSawData.load());

    auto toClient = stbipc::SharedBuffer::create(size, "to-client-test");
    void* clientMap = stbipc::mapSharedBuffer(toClient.fd(), size, true);
    std::memset(clientMap, 0x5A, size);
    (void)::munmap(clientMap, size);
    auto clientReply = server.callClient(cls, clientApi, {static_cast<std::uint64_t>(size)}, 2s, toClient.fd());
    assert(stbipc::argAs<bool>(clientReply.args, 0));
    assert(clientSawData.load());

    client.disconnect();
    server.stop();
    serverThread.join();
    return 0;
}
