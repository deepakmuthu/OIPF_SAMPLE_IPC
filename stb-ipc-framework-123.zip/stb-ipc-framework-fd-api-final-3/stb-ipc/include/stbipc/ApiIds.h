#pragma once
#include <cstdint>
namespace stbipc::api {
enum Class : std::uint32_t { Player=1, Drm=2, Tuner=3, Recorder=4, Epg=5, Plugin=6 };
enum PlayerApi : std::uint32_t { Play=1, Pause=2, GetState=3 };
enum DrmApi : std::uint32_t { SendLicense=1, OnMessageDrm=2, SendLicenseShared=3 };
enum TunerApi : std::uint32_t { Tune=1 };
enum RecorderApi : std::uint32_t { StartRecording=1 };
enum EpgApi : std::uint32_t { QueryNowNext=1, EpgEvent=2 };
enum PluginApi : std::uint32_t { Notify=1 };
}
