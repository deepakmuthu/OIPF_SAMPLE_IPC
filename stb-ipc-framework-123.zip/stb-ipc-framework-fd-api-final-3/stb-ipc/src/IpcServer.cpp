#include "stbipc/IpcServer.h"

#include <sys/socket.h>
#include <unistd.h>

#include <stdexcept>
#include <string>
#include <utility>
#include <vector>
#include <thread>

namespace stbipc {

IpcServer::IpcServer(std::string path)
    : path_(std::move(path))
{
}

IpcServer::~IpcServer()
{
    stop();
}

void IpcServer::registerApi(
    std::uint32_t classId,
    std::uint32_t apiId,
    ApiHandler handler)
{
    if (!handler) throw std::invalid_argument("registerApi requires a non-empty handler");
    std::lock_guard<std::mutex> lock(handlerMutex_);
    handlers_[Key{classId, apiId}] = std::move(handler);
}

void IpcServer::registerApiWithFd(
    std::uint32_t classId, std::uint32_t apiId, FdApiHandler handler)
{
    if (!handler) throw std::invalid_argument("registerApiWithFd requires a non-empty handler");
    std::lock_guard<std::mutex> lock(handlerMutex_);
    fdHandlers_[Key{classId, apiId}] = std::move(handler);
}

Message IpcServer::callClient(
    std::uint32_t classId, std::uint32_t apiId, Args args,
    std::chrono::milliseconds timeout,
    int attachedFd)
{
    if (attachedFd < -1) throw std::invalid_argument("attachedFd must be -1 or a valid descriptor");
    if (timeout.count() <= 0) {
        throw std::invalid_argument("callClient timeout must be positive");
    }
    if (stopRequested_.load()) {
        throw std::runtime_error("IPC server is stopping");
    }

    const auto requestId = nextRequestId_++;
    auto pending = std::make_shared<Pending>();
    {
        std::lock_guard<std::mutex> lock(pendingMutex_);
        pending_.emplace(requestId, pending);
    }

    Message request{MessageType::Request, requestId, classId, apiId, Status::Ok, std::move(args)};
    try {
        const auto bytes = encode(request);
        std::lock_guard<std::mutex> sendLock(sendMutex_);
        int fd = -1;
        {
            std::lock_guard<std::mutex> fdLock(fdMutex_);
            fd = clientFd_;
        }
        if (fd < 0 || stopRequested_.load()) {
            throw std::runtime_error("no connected IPC client");
        }
        if (attachedFd >= 0) sendFrameWithFd(fd, bytes, attachedFd);
        else sendFrame(fd, bytes);
    } catch (...) {
        std::lock_guard<std::mutex> lock(pendingMutex_);
        pending_.erase(requestId);
        throw;
    }

    std::unique_lock<std::mutex> lock(pending->mutex);
    if (!pending->cv.wait_for(lock, timeout, [&pending] { return pending->done; })) {
        lock.unlock();
        std::lock_guard<std::mutex> pendingLock(pendingMutex_);
        pending_.erase(requestId);
        throw std::runtime_error("server-to-client IPC call timed out");
    }
    if (pending->response.status != Status::Ok) {
        throw std::runtime_error("client API failed with status " +
            std::to_string(static_cast<unsigned>(pending->response.status)));
    }
    return pending->response;
}

bool IpcServer::waitUntilReady(std::chrono::milliseconds timeout)
{
    std::unique_lock<std::mutex> lock(stateMutex_);
    stateCv_.wait_for(lock, timeout, [this] {
        return ready_ || finished_;
    });
    return ready_ && startupError_.empty() && !stopRequested_.load();
}

void IpcServer::run()
{
    bool expected = false;
    if (!runStarted_.compare_exchange_strong(expected, true)) {
        throw std::logic_error("IpcServer::run() may only be called once");
    }

    try {
        if (stopRequested_.load()) {
            std::lock_guard<std::mutex> lock(stateMutex_);
            finished_ = true;
            stateCv_.notify_all();
            return;
        }

        const int listener = listenUnix(path_);
        {
            std::lock_guard<std::mutex> lock(fdMutex_);
            listenFd_ = listener;
            if (stopRequested_.load()) {
                (void)::shutdown(listenFd_, SHUT_RDWR);
            }
        }
        {
            std::lock_guard<std::mutex> lock(stateMutex_);
            ready_ = !stopRequested_.load();
            stateCv_.notify_all();
        }

        while (!stopRequested_.load()) {
            int listenerFd = -1;
            {
                std::lock_guard<std::mutex> lock(fdMutex_);
                listenerFd = listenFd_;
            }
            if (listenerFd < 0) {
                break;
            }

            int acceptedFd = -1;
            try {
                acceptedFd = acceptUnix(listenerFd);
            } catch (const std::exception&) {
                if (stopRequested_.load()) {
                    break;
                }
                throw;
            }

            {
                std::lock_guard<std::mutex> lock(fdMutex_);
                clientFd_ = acceptedFd;
                if (stopRequested_.load()) {
                    (void)::shutdown(clientFd_, SHUT_RDWR);
                }
            }

            if (!stopRequested_.load()) {
                handleClient(acceptedFd);
            }
            closeClientFromRunThread(acceptedFd);
        }
    } catch (const std::exception& error) {
        const bool shouldRethrow = !stopRequested_.load();
        {
            std::lock_guard<std::mutex> lock(stateMutex_);
            if (!ready_) {
                startupError_ = error.what();
            }
            finished_ = true;
            stateCv_.notify_all();
        }
        closeClientFromRunThread(-1);
        closeListenerFromRunThread();
        if (shouldRethrow) {
            throw;
        }
        return;
    }

    closeClientFromRunThread(-1);
    closeListenerFromRunThread();
    {
        std::lock_guard<std::mutex> lock(stateMutex_);
        finished_ = true;
        stateCv_.notify_all();
    }
}

void IpcServer::stop() noexcept
{
    stopRequested_.store(true);

    // Interrupt a blocking receive on the active client. The run thread owns
    // close(), so stop() never closes a descriptor that the I/O thread may be
    // using (and therefore cannot trigger descriptor-reuse races).
    {
        std::lock_guard<std::mutex> lock(fdMutex_);
        if (clientFd_ >= 0) {
            (void)::shutdown(clientFd_, SHUT_RDWR);
        }
    }

    // A shutdown() on a listening AF_UNIX socket is not a portable/reliable
    // way to wake accept(). Connect once to our own socket instead. The run
    // thread sees stopRequested_, closes this wake-up client, and exits.
    try {
        const int wakeFd = connectUnix(path_);
        int fd = wakeFd;
        closeFd(fd);
    } catch (...) {
        // Expected if startup never reached listen(); the run loop also checks
        // stopRequested_ before entering accept().
    }
    stateCv_.notify_all();
}

void IpcServer::closeClientFromRunThread(int clientFd) noexcept
{
    std::lock_guard<std::mutex> sendLock(sendMutex_);
    std::lock_guard<std::mutex> fdLock(fdMutex_);

    const int fdToClose = (clientFd >= 0) ? clientFd : clientFd_;
    if (fdToClose >= 0) {
        (void)::shutdown(fdToClose, SHUT_RDWR);
        (void)::close(fdToClose);
    }
    if (clientFd_ == fdToClose) {
        clientFd_ = -1;
    }
}

void IpcServer::closeListenerFromRunThread() noexcept
{
    std::lock_guard<std::mutex> lock(fdMutex_);
    if (listenFd_ >= 0) {
        (void)::shutdown(listenFd_, SHUT_RDWR);
        (void)::close(listenFd_);
        listenFd_ = -1;
    }
    (void)::unlink(path_.c_str());
}

void IpcServer::emitEvent(
    std::uint32_t classId,
    std::uint32_t apiId,
    Args args)
{
    Message event{
        MessageType::Event,
        0,
        classId,
        apiId,
        Status::Ok,
        std::move(args)};
    const auto bytes = encode(event);

    // Keep the send lock while reading and using clientFd_: the run thread
    // takes the same lock before closing it.
    std::lock_guard<std::mutex> sendLock(sendMutex_);
    int fd = -1;
    {
        std::lock_guard<std::mutex> fdLock(fdMutex_);
        fd = clientFd_;
    }
    if (fd < 0 || stopRequested_.load()) {
        return;
    }
    sendFrame(fd, bytes);
}

void IpcServer::failPending(Status status) noexcept
{
    std::map<std::uint64_t, std::shared_ptr<Pending>> failed;
    {
        std::lock_guard<std::mutex> lock(pendingMutex_);
        failed.swap(pending_);
    }
    for (auto& item : failed) {
        auto& pending = item.second;
        {
            std::lock_guard<std::mutex> lock(pending->mutex);
            if (!pending->done) {
                pending->done = true;
                pending->response.status = status;
            }
        }
        pending->cv.notify_all();
    }
}

void IpcServer::dispatchRequest(int fd, Message request) noexcept
{
    std::unique_ptr<int, void(*)(int*)> fdOwner(&request.attachedFd, [](int* descriptor) { if (*descriptor >= 0) { ::close(*descriptor); *descriptor = -1; } });
    Message response{MessageType::Response, request.requestId, request.classId,
                     request.apiId, Status::Ok, {}};
    try {
        ApiHandler handler;
        FdApiHandler fdHandler;
        {
            std::lock_guard<std::mutex> lock(handlerMutex_);
            const Key key{request.classId, request.apiId};
            const auto fdIt = fdHandlers_.find(key);
            const auto it = handlers_.find(key);
            if (fdIt != fdHandlers_.end()) fdHandler = fdIt->second;
            else if (it != handlers_.end()) handler = it->second;
            else response.status = Status::NotFound;
        }
        if (fdHandler) response.args = fdHandler(request.args, request.attachedFd);
        else if (handler) {
            if (request.attachedFd >= 0) response.status = Status::InvalidArgument;
            else response.args = handler(request.args);
        }
    } catch (const std::invalid_argument&) {
        response.status = Status::InvalidArgument;
    } catch (const std::out_of_range&) {
        response.status = Status::InvalidArgument;
    } catch (...) {
        response.status = Status::InternalError;
    }

    if (request.type != MessageType::Request || stopRequested_.load()) {
        return; // One-way APIs do not have responses.
    }
    try {
        const auto bytes = encode(response);
        std::lock_guard<std::mutex> sendLock(sendMutex_);
        {
            std::lock_guard<std::mutex> fdLock(fdMutex_);
            // Do not send on a stale descriptor after client reconnect/FD reuse.
            if (clientFd_ != fd || stopRequested_.load()) {
                return;
            }
        }
        sendFrame(fd, bytes);
    } catch (...) {
        // A failed reply is detected by the receive loop / peer disconnect path.
    }
}

void IpcServer::handleClient(int fd)
{
    // Dispatch request handlers away from the receive loop. This is essential:
    // a handler may call callClient(), while this loop must remain available to
    // receive that client's reply. Each worker is joined before this connection
    // is torn down; handlers should use bounded waits and avoid infinite loops.
    struct HandlerWorker { std::shared_ptr<std::atomic<bool>> done; std::thread thread; };
    std::vector<HandlerWorker> workers;
    constexpr std::size_t kMaxConcurrentHandlers = 32;
    while (!stopRequested_.load()) {
        Message message;
        try {
            auto frame = receiveFrameWithFd(fd);
            try { message = decode(frame.payload); }
            catch (...) { if (frame.fd >= 0) ::close(frame.fd); throw; }
            message.attachedFd = frame.fd;
        } catch (...) {
            break;
        }

        if (message.type == MessageType::Response) {
            if (message.attachedFd >= 0) { ::close(message.attachedFd); throw ProtocolError("FDs on responses are not supported; attach FDs to requests"); }
            std::shared_ptr<Pending> pending;
            {
                std::lock_guard<std::mutex> lock(pendingMutex_);
                const auto it = pending_.find(message.requestId);
                if (it != pending_.end()) {
                    pending = it->second;
                    pending_.erase(it);
                }
            }
            if (pending) {
                {
                    std::lock_guard<std::mutex> lock(pending->mutex);
                    pending->response = std::move(message);
                    pending->done = true;
                }
                pending->cv.notify_all();
            }
        } else if (message.type == MessageType::Request ||
                   message.type == MessageType::OneWay) {
            // Reap completed workers and cap concurrent handlers to protect the
            // Middleware process from unbounded thread creation under load.
            for (auto it = workers.begin(); it != workers.end();) {
                if (it->done->load()) {
                    if (it->thread.joinable()) it->thread.join();
                    it = workers.erase(it);
                } else {
                    ++it;
                }
            }
            if (workers.size() >= kMaxConcurrentHandlers) {
                if (message.attachedFd >= 0) ::close(message.attachedFd);
                if (message.type == MessageType::Request) {
                    Message busy{MessageType::Response, message.requestId,
                                 message.classId, message.apiId,
                                 Status::InternalError, {}};
                    try {
                        const auto bytes = encode(busy);
                        std::lock_guard<std::mutex> sendLock(sendMutex_);
                        {
                            std::lock_guard<std::mutex> fdLock(fdMutex_);
                            if (clientFd_ != fd) continue;
                        }
                        sendFrame(fd, bytes);
                    } catch (...) {
                        break;
                    }
                }
                continue; // Drop overloaded one-way calls; no response is defined.
            }
            auto done = std::make_shared<std::atomic<bool>>(false);
            HandlerWorker worker;
            worker.done = done;
            worker.thread = std::thread([this, fd, done, request = std::move(message)]() mutable {
                dispatchRequest(fd, std::move(request));
                done->store(true);
            });
            workers.push_back(std::move(worker));
        } else {
            if (message.attachedFd >= 0) ::close(message.attachedFd);
            break; // Events are server-originated; unexpected peer message is invalid.
        }
    }

    // Wake server-side calls before joining handlers; a handler may itself be
    // waiting in callClient() and must not keep shutdown waiting for its timeout.
    failPending(Status::Disconnected);
    for (auto& worker : workers) {
        if (worker.thread.joinable()) {
            worker.thread.join();
        }
    }
}

} // namespace stbipc
