#include "stbipc/IpcClient.h"

#include <sys/socket.h>
#include <unistd.h>
#include <cerrno>
#include <cstring>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

namespace stbipc {
namespace {
constexpr std::chrono::seconds kSocketSendTimeout{3};

void configureSendTimeout(int fd)
{
    const timeval timeout{
        static_cast<time_t>(kSocketSendTimeout.count()), 0};
    if (::setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &timeout, sizeof(timeout)) < 0) {
        throw std::runtime_error(
            std::string("setsockopt(SO_SNDTIMEO) failed: ") + std::strerror(errno));
    }
}
} // namespace

IpcClient::IpcClient(std::string path)
    : path_(std::move(path))
{
}

IpcClient::~IpcClient()
{
    disconnect();
}

void IpcClient::connect()
{
    std::lock_guard<std::mutex> stateLock(stateMutex_);
    if (running_) {
        return;
    }
    if (reader_.joinable()) {
        throw std::logic_error("IPC reader thread must be joined before reconnecting");
    }

    int socketFd = connectUnix(path_);
    try {
        configureSendTimeout(socketFd);
        fd_ = socketFd;
        running_ = true;
        reader_ = std::thread(&IpcClient::readerLoop, this);
    } catch (...) {
        running_ = false;
        fd_ = -1;
        closeFd(socketFd);
        throw;
    }
}

void IpcClient::disconnect() noexcept
{
    running_ = false;
    {
        std::lock_guard<std::mutex> stateLock(stateMutex_);
        if (fd_ >= 0) {
            // shutdown() wakes a blocking receive. The reader thread closes fd_
            // after it exits, avoiding close/reuse races with recv()/send().
            (void)::shutdown(fd_, SHUT_RDWR);
        }
    }

    if (reader_.joinable() && reader_.get_id() != std::this_thread::get_id()) {
        reader_.join();
    }

    failPending(Status::Disconnected);
}

bool IpcClient::connected() const noexcept
{
    return running_.load();
}

Message IpcClient::call(
    std::uint32_t classId,
    std::uint32_t apiId,
    Args args,
    std::chrono::milliseconds timeout,
    int attachedFd)
{
    if (timeout.count() <= 0) throw std::invalid_argument("IPC call timeout must be positive");
    if (attachedFd < -1) throw std::invalid_argument("attachedFd must be -1 or a valid descriptor");
    if (!running_) {
        throw std::runtime_error("IPC client is not connected");
    }

    const auto requestId = nextId_++;
    auto pending = std::make_shared<Pending>();
    {
        std::lock_guard<std::mutex> lock(pendingMutex_);
        if (!running_) {
            throw std::runtime_error("IPC client is disconnecting");
        }
        pending_.emplace(requestId, pending);
    }

    Message request{
        MessageType::Request, requestId, classId, apiId, Status::Ok, std::move(args)};

    try {
        const auto bytes = encode(request);
        std::lock_guard<std::mutex> sendLock(sendMutex_);
        int socketFd = -1;
        {
            std::lock_guard<std::mutex> stateLock(stateMutex_);
            if (!running_ || fd_ < 0) {
                throw std::runtime_error("IPC client disconnected before send");
            }
            socketFd = fd_;
        }
        // sendMutex_ prevents the reader from closing/reusing this descriptor;
        // stateMutex_ is released so disconnect() can shutdown() a blocked send.
        if (attachedFd >= 0) sendFrameWithFd(socketFd, bytes, attachedFd);
        else sendFrame(socketFd, bytes);
    } catch (...) {
        {
            std::lock_guard<std::mutex> lock(pendingMutex_);
            pending_.erase(requestId);
        }
        throw;
    }

    std::unique_lock<std::mutex> lock(pending->mutex);
    if (!pending->cv.wait_for(lock, timeout, [&pending] { return pending->done; })) {
        lock.unlock();
        std::lock_guard<std::mutex> pendingLock(pendingMutex_);
        pending_.erase(requestId);
        throw std::runtime_error("IPC request timed out waiting for response");
    }

    if (pending->response.status != Status::Ok) {
        throw std::runtime_error(
            "IPC request failed with status " +
            std::to_string(static_cast<unsigned>(pending->response.status)));
    }
    return pending->response;
}

void IpcClient::sendOneWay(std::uint32_t classId, std::uint32_t apiId, Args args)
{
    if (!running_) {
        throw std::runtime_error("IPC client is not connected");
    }

    Message message{MessageType::OneWay, 0, classId, apiId, Status::Ok, std::move(args)};
    const auto bytes = encode(message);
    std::lock_guard<std::mutex> sendLock(sendMutex_);
    int socketFd = -1;
    {
        std::lock_guard<std::mutex> stateLock(stateMutex_);
        if (!running_ || fd_ < 0) {
            throw std::runtime_error("IPC client disconnected before send");
        }
        socketFd = fd_;
    }
    sendFrame(socketFd, bytes);
}

void IpcClient::registerApi(std::uint32_t classId, std::uint32_t apiId, ApiHandler handler)
{
    if (!handler) {
        throw std::invalid_argument("registerApi requires a non-empty handler");
    }
    std::lock_guard<std::mutex> lock(apiMutex_);
    apiHandlers_[ApiKey{classId, apiId}] = std::move(handler);
}

void IpcClient::registerApiWithFd(
    std::uint32_t classId, std::uint32_t apiId, FdApiHandler handler)
{
    if (!handler) throw std::invalid_argument("registerApiWithFd requires a non-empty handler");
    std::lock_guard<std::mutex> lock(apiMutex_);
    fdApiHandlers_[ApiKey{classId, apiId}] = std::move(handler);
}

void IpcClient::setEventHandler(EventHandler handler)
{
    std::lock_guard<std::mutex> lock(eventMutex_);
    eventHandler_ = std::move(handler);
}

void IpcClient::failPending(Status status) noexcept
{
    std::map<std::uint64_t, std::shared_ptr<Pending>> pendingToFail;
    {
        std::lock_guard<std::mutex> pendingLock(pendingMutex_);
        pendingToFail.swap(pending_);
    }

    for (auto& entry : pendingToFail) {
        const auto& pending = entry.second;
        {
            std::lock_guard<std::mutex> itemLock(pending->mutex);
            if (!pending->done) {
                pending->done = true;
                pending->response.status = status;
            }
        }
        pending->cv.notify_all();
    }
}

void IpcClient::closeSocketFromReader() noexcept
{
    // Match send-side lock order. fd_ is never closed while another thread may
    // still be using it in sendFrame().
    std::lock_guard<std::mutex> sendLock(sendMutex_);
    std::lock_guard<std::mutex> stateLock(stateMutex_);
    closeFd(fd_);
}

void IpcClient::dispatchIncoming(Message request) noexcept
{
    std::unique_ptr<int, void(*)(int*)> fdOwner(&request.attachedFd, [](int* fd) { if (*fd >= 0) { ::close(*fd); *fd = -1; } });
    Message response{MessageType::Response, request.requestId, request.classId,
                     request.apiId, Status::Ok, {}};
    try {
        ApiHandler handler;
        FdApiHandler fdHandler;
        {
            std::lock_guard<std::mutex> lock(apiMutex_);
            const ApiKey key{request.classId, request.apiId};
            const auto fdIt = fdApiHandlers_.find(key);
            const auto it = apiHandlers_.find(key);
            if (fdIt != fdApiHandlers_.end()) fdHandler = fdIt->second;
            else if (it != apiHandlers_.end()) handler = it->second;
            else response.status = Status::NotFound;
        }
        if (fdHandler) response.args = fdHandler(request.args, request.attachedFd);
        else if (handler) {
            if (request.attachedFd >= 0) response.status = Status::InvalidArgument;
            else response.args = handler(request.args);
        }
    } catch (const std::invalid_argument&) {
        response.status = Status::InvalidArgument;
    } catch (const std::out_of_range&) {
        response.status = Status::InvalidArgument;
    } catch (...) {
        response.status = Status::InternalError;
    }

    // One-way calls deliberately have no response. For requests, use the same
    // send -> state lock order as disconnect/reader close to prevent FD races.
    if (request.type != MessageType::Request || !running_) {
        return;
    }
    try {
        const auto bytes = encode(response);
        std::lock_guard<std::mutex> sendLock(sendMutex_);
        int socketFd = -1;
        {
            std::lock_guard<std::mutex> stateLock(stateMutex_);
            if (!running_ || fd_ < 0) {
                return;
            }
            socketFd = fd_;
        }
        sendFrame(socketFd, bytes);
    } catch (...) {
        // A failed response send is handled by the reader/disconnect lifecycle.
    }
}

void IpcClient::readerLoop() noexcept
{
    // Incoming API handlers execute away from the reader thread. This allows
    // the reader to keep receiving replies even when a handler performs call().
    // Threads are joined before the socket is finally closed. Applications must
    // keep handlers bounded and must not destroy this client from its handler.
    struct HandlerWorker { std::shared_ptr<std::atomic<bool>> done; std::thread thread; };
    std::vector<HandlerWorker> handlerThreads;
    constexpr std::size_t kMaxConcurrentHandlers = 32;
    try {
        while (running_) {
            int socketFd = -1;
            {
                std::lock_guard<std::mutex> stateLock(stateMutex_);
                socketFd = fd_;
            }
            if (socketFd < 0 || !running_) {
                break;
            }

            auto frame = receiveFrameWithFd(socketFd);
            Message message;
            try { message = decode(frame.payload); }
            catch (...) { if (frame.fd >= 0) ::close(frame.fd); throw; }
            message.attachedFd = frame.fd;
            if (message.type == MessageType::Response) {
                if (message.attachedFd >= 0) { ::close(message.attachedFd); throw ProtocolError("FDs on responses are not supported; attach FDs to requests"); }
                std::shared_ptr<Pending> pending;
                {
                    std::lock_guard<std::mutex> lock(pendingMutex_);
                    const auto it = pending_.find(message.requestId);
                    if (it != pending_.end()) {
                        pending = it->second;
                        pending_.erase(it);
                    }
                }
                if (pending) {
                    {
                        std::lock_guard<std::mutex> lock(pending->mutex);
                        pending->response = std::move(message);
                        pending->done = true;
                    }
                    pending->cv.notify_all();
                }
            } else if (message.type == MessageType::Request ||
                       message.type == MessageType::OneWay) {
                // Reap completed workers so a long-lived connection does not
                // accumulate one joinable thread object per historical request.
                for (auto it = handlerThreads.begin(); it != handlerThreads.end();) {
                    if (it->done->load()) {
                        if (it->thread.joinable()) it->thread.join();
                        it = handlerThreads.erase(it);
                    } else {
                        ++it;
                    }
                }
                if (handlerThreads.size() >= kMaxConcurrentHandlers) {
                    if (message.attachedFd >= 0) ::close(message.attachedFd);
                    if (message.type == MessageType::Request) {
                        Message busy{MessageType::Response, message.requestId,
                                     message.classId, message.apiId,
                                     Status::InternalError, {}};
                        const auto bytes = encode(busy);
                        std::lock_guard<std::mutex> sendLock(sendMutex_);
                        int fd = -1;
                        {
                            std::lock_guard<std::mutex> stateLock(stateMutex_);
                            if (running_) fd = fd_;
                        }
                        if (fd >= 0) sendFrame(fd, bytes);
                    }
                    continue; // Reject overload instead of spawning unbounded threads.
                }
                auto done = std::make_shared<std::atomic<bool>>(false);
                HandlerWorker worker;
                worker.done = done;
                worker.thread = std::thread(
                    [this, done, request = std::move(message)]() mutable {
                        dispatchIncoming(std::move(request));
                        done->store(true);
                    });
                handlerThreads.push_back(std::move(worker));
            } else if (message.type == MessageType::Event) {
                if (message.attachedFd >= 0) { ::close(message.attachedFd); throw ProtocolError("FDs on events are not supported"); }
                EventHandler handler;
                {
                    std::lock_guard<std::mutex> lock(eventMutex_);
                    handler = eventHandler_;
                }
                if (handler) {
                    try { handler(message); } catch (...) { /* Isolate user callback failures. */ }
                }
            } else {
                if (message.attachedFd >= 0) ::close(message.attachedFd);
                throw ProtocolError("unexpected message type received by IPC client");
            }
        }
    } catch (...) {
        running_ = false;
        failPending(Status::Disconnected);
    }

    running_ = false;
    failPending(Status::Disconnected);
    for (auto& worker : handlerThreads) {
        if (worker.thread.joinable()) {
            // A handler's nested call() is released by failPending() above.
            worker.thread.join();
        }
    }
    closeSocketFromReader();
}

} // namespace stbipc
