# STB IPC Framework — API Reference

This document describes the public C++ APIs in `include/stbipc/`. The framework is a Linux/C++17 prototype for communication between a WebKitWPE WebProcess plugin and a separate native Middleware process.

## 1. Build and run

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j4
ctest --test-dir build --output-on-failure
```

Demo:

```bash
# Terminal 1: Middleware-side server
./build/stb_ipc_server /tmp/stb-ipc-demo.sock

# Terminal 2: WebProcess-side demo client
./build/stb_ipc_client /tmp/stb-ipc-demo.sock
```

## 2. Public headers

| Header | Responsibility |
|---|---|
| `stbipc/Value.h` | Supported parameter types and `argAs<T>()` |
| `stbipc/Protocol.h` | Message structure, message/status enums, `encode()` and `decode()` |
| `stbipc/ApiIds.h` | Stable numeric class/API identifiers |
| `stbipc/UnixSocket.h` | Unix socket setup, frame I/O, and `SCM_RIGHTS` FD passing |
| `stbipc/SharedBuffer.h` | Linux `memfd` shared buffers and `mmap` helper |
| `stbipc/IpcClient.h` | Client request/reply, one-way calls and event callbacks |
| `stbipc/IpcServer.h` | Server API registration and event emission |
| `stbipc/Services.h` | Demo service registration |

## 3. Typed parameters

`Value` is a `std::variant` supporting:

| C++ type | Wire type | Typical use |
|---|---|---|
| `std::int32_t` | `I32` | Signed counters/status values |
| `std::uint32_t` | `U32` | Channel IDs, message types, durations |
| `std::int64_t` | `I64` | Signed timestamps or large counters |
| `std::uint64_t` | `U64` | IDs and unsigned counters |
| `bool` | `Bool` | Flags such as autoplay |
| `double` | `Double` | Numeric values requiring floating point |
| `std::string` | `String` | URLs, DRM XML, system IDs, event names |
| `stbipc::Bytes` | `Bytes` | Small binary blobs or metadata |

An API can have zero or multiple arguments. The current protocol caps the argument count at 64 and the complete serialized frame at 4 MiB. Large media payloads should be sent through a shared buffer FD, not placed in `Bytes`.

### Typed extraction

```cpp
const auto& url = stbipc::argAs<std::string>(message.args, 0);
const bool autoplay = stbipc::argAs<bool>(message.args, 1);
```

`argAs<T>(args, index)`:

- `args`: decoded argument vector.
- `index`: zero-based argument position.
- Returns: `const T&` to the value in the vector.
- Throws `std::out_of_range` if the index is absent.
- Throws `std::invalid_argument` if the value has a different type.

Each registered handler must also validate the exact argument count and business-specific value ranges. `argAs<T>()` alone does not reject extra arguments.

## 4. Message and protocol APIs

### `Message`

Fields:

- `type`: `Request`, `Response`, `Event`, or `OneWay`.
- `requestId`: nonzero for request/reply correlation; use zero for events and one-way messages.
- `classId`, `apiId`: stable numeric route key.
- `status`: `Ok`, `InvalidArgument`, `NotFound`, `InternalError`, `Unsupported`, `Timeout`, or `Disconnected`.
- `args`: typed argument list.

### `encode(const Message&)`

Serializes a message to `std::vector<std::uint8_t>`. Throws `ProtocolError` for unsupported/oversized payloads.

### `decode(data, size)` / `decode(vector)`

Validates the protocol header/version and decodes typed arguments. Use the vector overload when consuming the output of `receiveFrame()`.

## 5. Unix socket APIs

### `connectUnix(path)`

Connects to an existing Unix domain socket. `path` is the filesystem socket path. Returns a connected FD or throws `std::runtime_error`.

### `listenUnix(path, backlog = 8)`

Creates, binds and listens on a filesystem Unix socket. `backlog` controls the pending connection queue. Returns the listening FD. The current demo removes an existing path before binding; in production, use a service-owned directory and verify ownership before unlinking any path.

### `acceptUnix(listenFd)`

Accepts one client and returns a close-on-exec client FD.

### `sendFrame(socketFd, payload)` / `receiveFrame(socketFd)`

Send or receive one length-prefixed frame. `payload` is serialized protocol data, usually `encode(message)`. The 4-byte frame length is little-endian. These ordinary-frame functions reject unexpected attached FDs (and close the received FD).

### `sendFrameWithFd(socketFd, payload, fdToSend)`

Sends a regular frame and transfers one open file descriptor using `sendmsg()` with `SCM_RIGHTS`.

- `socketFd`: connected `AF_UNIX` stream socket.
- `payload`: normal serialized IPC message; should include metadata describing the buffer, such as buffer size, usage, format, width/height and stride.
- `fdToSend`: open memfd/shared-memory FD or DMA-BUF FD. The sender retains its own FD; SCM_RIGHTS gives the receiver a new descriptor referring to the same underlying object.
- Returns: `void`; throws on send failure or invalid frame.

### `receiveFrameWithFd(socketFd)`

Receives one frame and optional attached descriptor. Returns `ReceivedFrame`:

- `payload`: decoded by the caller with `decode()`.
- `fd`: descriptor owned by the caller, or `-1` if no FD arrived.

The caller must close the returned FD. The current helper permits at most one FD per frame. A single-FD DMA-BUF is supported. Multi-plane DMA-BUFs that require multiple plane FDs need a bounded multi-FD extension and a documented plane layout.

**Important stream rule:** the ancillary FD is associated with the beginning of the frame. Do not read the socket with a separate `recv()` before calling `receiveFrameWithFd()`, or the FD may be separated from its frame. On a connection that carries FDs, all reads must go through the same framing/ancillary-data reader.

## 6. Shared-memory APIs

### `SharedBuffer::create(size, name = "stb-ipc-buffer")`

Creates a Linux `memfd` object and sizes it with `ftruncate()`.

- `size`: requested bytes; must be greater than zero and no more than 512 MiB in this prototype.
- `name`: diagnostic name visible in Linux process/memory tools; not a security boundary.
- Returns: move-only `SharedBuffer`, owning an FD and recording the size.

`buffer.fd()` borrows the FD; `buffer.size()` returns the size; `buffer.release()` transfers FD ownership to the caller; `buffer.reset()` closes the FD. The class is move-only to avoid accidental double-close.

### `mapSharedBuffer(fd, size, writable)`

Maps a received or locally owned buffer with `mmap(MAP_SHARED)`.

- `fd`: open FD for the shared memory/DMA buffer.
- `size`: requested mapping length. The helper checks that `fstat()` reports at least this many bytes and rejects sizes over the configured limit.
- `writable`: `true` maps read/write; `false` maps read-only.
- Returns: mapped address; caller must call `munmap(address, size)`.

The receiver must not trust a size supplied by the peer. Apply per-service limits and verify metadata before mapping. The sender and receiver must define who may read/write, when the producer has finished, when the consumer is done, and when the buffer may be reused. `SCM_RIGHTS` transfers a descriptor, not buffer ownership policy or synchronization.

### DMA-BUF note

`sendFrameWithFd()` can transfer a DMA-BUF FD exactly like a memfd. The framework does not allocate a DMA-BUF, import it into a graphics/media API, or manage fences. The media adapter must obtain the FD from the platform allocator/player, carry the format/plane metadata, use the appropriate importer, and coordinate fences/cache synchronization according to the platform's DMA-BUF contract. Do not assume a plain CPU `mmap()` is valid for every DMA-BUF.

## 7. Class/API IDs

`ApiIds.h` currently reserves these classes:

| Class | ID | Example APIs |
|---|---:|---|
| Player | 1 | `Play=1`, `Pause=2`, `GetState=3` |
| DRM | 2 | `SendLicense=1`, `OnMessageDrm=2` |
| Tuner | 3 | `Tune=1` |
| Recorder | 4 | `StartRecording=1` |
| EPG | 5 | `QueryNowNext=1`, `EpgEvent=2` |
| Plugin | 6 | `Notify=1` |

IDs are part of the wire contract. Do not renumber an ID already used by deployed peers. Document argument types, return types, call mode and compatibility whenever adding an API.

## 8. API contract examples

These are the demo's intended argument contracts; update the handlers and this table together when connecting product services.

| Class/API | Request arguments | Response/event arguments | Mode |
|---|---|---|---|
| Player `Play` | `string url`, `bool autoplay` | `string result` | Request/reply |
| Player `Pause` | none | none | Request/reply |
| Player `GetState` | none | `string state`, `uint32 stateCode` | Request/reply |
| DRM `SendLicense` | `string xml`, `string systemID`, `uint32 messageType` | `bool accepted`, `string result` | Request/reply |
| DRM `OnMessageDrm` | event-specific fields defined by product contract | event-specific fields | Event (define schema before use) |
| Tuner `Tune` | `uint32 channel` | `bool accepted` | Request/reply |
| Recorder `StartRecording` | `string recordingId`, `uint32 durationSeconds` | `string result` | Request/reply |
| EPG `QueryNowNext` | `uint32 serviceId` | `uint32 serviceId`, `string now`, `string next` | Request/reply |
| EPG `EpgEvent` | product-defined event fields | product-defined event fields | Event |
| Plugin `Notify` | `string eventName` | none | One-way |

For DRM XML, use a `std::string` for XML text and keep `systemID` and `messageType` as separate typed arguments. Never serialize a C++ pointer, native object layout, or raw struct with padding into the wire protocol.

## 9. Request/reply and event flow

1. Client builds a `Message` with `type=Request`, a unique nonzero `requestId`, `classId`, `apiId`, and typed `args`.
2. Client serializes it with `encode()` and sends it with `sendFrame()`.
3. Server decodes it and dispatches using `(classId, apiId)`.
4. Server returns a `Response` with the same `requestId` and route IDs.
5. Client matches the response to the waiting request. Events are delivered through the event callback and should not be mistaken for replies.

For buffer transfer, put the metadata in the protocol message and send that encoded message with `sendFrameWithFd()`. The receiver must use `receiveFrameWithFd()` for that frame, decode the metadata, validate it, map/import the FD, and close the received FD when finished.

## 10. Production checklist

- Place the socket in a service-owned directory and set restrictive permissions; authenticate peers with `SO_PEERCRED`.
- Add a version/capability handshake and per-API schema validation.
- Enforce per-API timeouts, cancellation, rate limits and bounded queues.
- Use a single coordinated reader for all frames and ancillary descriptors on each connection.
- Bound frame, string, byte-array and shared-buffer sizes. Reject invalid FDs, mismatched metadata and unexpected descriptors.
- Specify buffer lifetime/ownership, read/write roles, fences and reuse protocol; never reuse a buffer while the other process is consuming it.
- Test peer disconnect during transfer, malformed lengths, truncated ancillary data, unexpected/multiple FDs, undersized buffers and permission failures.
- Use a bounded worker pool and multi-client server if required by the product.
- Keep IPC reader callbacks short; dispatch events onto the WebProcess/plugin's appropriate thread.
- Replace mock services with real middleware adapters and perform end-to-end WebKitWPE integration tests.
